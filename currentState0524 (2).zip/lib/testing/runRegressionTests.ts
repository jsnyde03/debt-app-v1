import "../engine/testAllocation";
import "../debt/testDebtProjection";
import "./testPlannerStateHardening";
import "./testStressScenarios";
import "./testAbuseScenarios";
import "./testAprMath";

console.log("✅ All regression tests passed.");