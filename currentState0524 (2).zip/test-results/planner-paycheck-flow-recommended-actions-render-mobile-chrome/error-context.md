# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: planner-paycheck-flow.spec.ts >> recommended actions render
- Location: tests\e2e\planner-paycheck-flow.spec.ts:121:5

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('.bottom-nav-item').filter({ hasText: 'Plan' })
    - locator resolved to <button type="button" class="bottom-nav-item active">…</button>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <button type="button" class="primary-plan-button">Calculate plan</button> from <div class="settings-overlay">…</div> subtree intercepts pointer events
    - retrying click action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <button type="button" class="primary-plan-button">Calculate plan</button> from <div class="settings-overlay">…</div> subtree intercepts pointer events
    - retrying click action
      - waiting 100ms
    49 × waiting for element to be visible, enabled and stable
       - element is visible, enabled and stable
       - scrolling into view if needed
       - done scrolling
       - <button type="button" class="primary-plan-button">Calculate plan</button> from <div class="settings-overlay">…</div> subtree intercepts pointer events
     - retrying click action
       - waiting 500ms

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - main [ref=e2]:
    - generic [ref=e3]:
      - heading "Debt Planner" [level=1] [ref=e4]
      - paragraph [ref=e5]: Enter a paycheck and see exactly what to do next.
      - button "Dark Mode" [ref=e6] [cursor=pointer]
      - navigation [ref=e7]:
        - button "🏠 Plan" [ref=e8] [cursor=pointer]:
          - generic [ref=e9]: 🏠
          - generic [ref=e10]: Plan
        - button "💳 Bills" [ref=e11] [cursor=pointer]:
          - generic [ref=e12]: 💳
          - generic [ref=e13]: Bills
        - button "📈 Payoff" [ref=e14] [cursor=pointer]:
          - generic [ref=e15]: 📈
          - generic [ref=e16]: Payoff
        - button "🎯 Goals" [ref=e17] [cursor=pointer]:
          - generic [ref=e18]: 🎯
          - generic [ref=e19]: Goals
    - button "Plan Settings" [ref=e21] [cursor=pointer]
    - generic [ref=e23]:
      - heading "Plan Settings" [level=2] [ref=e25]
      - paragraph [ref=e26]: Enter your paycheck amount to create your first plan.
      - generic [ref=e27]: First Time Setup
      - generic [ref=e28]:
        - heading "Paycheck" [level=2] [ref=e29]
        - generic [ref=e30]:
          - generic [ref=e31]:
            - generic [ref=e32]: Paycheck Amount
            - 'textbox "Example: 1000" [ref=e33]'
          - generic [ref=e34]:
            - generic [ref=e35]: Pay Cycle
            - combobox [ref=e36]:
              - option "Weekly"
              - option "Bi-Weekly" [selected]
              - option "Semi-Monthly"
              - option "Monthly"
          - generic [ref=e37]:
            - generic [ref=e38]: Next Paycheck Date
            - textbox [ref=e39]: 2026-06-07
          - paragraph [ref=e40]:
            - text: "Current plan date: 2026-05-24"
            - text: Plan covers items due before 2026-06-07.
          - button "Calculate plan" [ref=e41] [cursor=pointer]
  - button "Open Next.js Dev Tools" [ref=e47] [cursor=pointer]:
    - img [ref=e48]
  - alert [ref=e51]
```

# Test source

```ts
  22  |                     recurrence: "monthly",
  23  |                     isPaidThisCycle: false,
  24  |                 },
  25  |                 {
  26  |                     id: "electric",
  27  |                     name: "Electric",
  28  |                     amount: 150,
  29  |                     dueDate: "2026-05-30",
  30  |                     recurrence: "monthly",
  31  |                     isPaidThisCycle: false,
  32  |                 },
  33  |             ])
  34  |         );
  35  | 
  36  |         localStorage.setItem(
  37  |             "debtPlanner.debts",
  38  |             JSON.stringify([
  39  |                 {
  40  |                     id: "visa",
  41  |                     name: "Visa",
  42  |                     balance: 500,
  43  |                     minimumPayment: 50,
  44  |                     apr: 22,
  45  |                     dueDate: "2026-05-29",
  46  |                     type: "debt",
  47  |                     recurrence: "monthly",
  48  |                     isPaidThisCycle: false,
  49  |                     minimumPaidThisCycle: false,
  50  |                     snowballPaidThisCycle: false,
  51  |                 },
  52  |             ])
  53  |         );
  54  | 
  55  |         localStorage.setItem(
  56  |             "debtPlanner.goals",
  57  |             JSON.stringify([
  58  |                 {
  59  |                     id: "emergency",
  60  |                     name: "Emergency Fund",
  61  |                     targetAmount: 1000,
  62  |                     currentAmount: 200,
  63  |                     type: "emergency",
  64  |                 },
  65  |             ])
  66  |         );
  67  | 
  68  |         localStorage.setItem("debtPlanner.completedRecommendedActions", JSON.stringify([]));
  69  |         localStorage.setItem("debtPlanner.payoffStrategy", JSON.stringify("snowball"));
  70  |         localStorage.setItem("debtPlanner.darkMode", JSON.stringify(false));
  71  |     });
  72  | 
  73  |     await page.reload();
  74  | 
  75  |     const overlay = page.locator(".settings-overlay");
  76  | 
  77  |     if (await overlay.isVisible().catch(() => false)) {
  78  |         await page.getByRole("button", { name: /Calculate plan/i }).click();
  79  | 
  80  |         await page.evaluate(() => {
  81  |             localStorage.setItem("debtPlanner.hasConfiguredPaycheck", JSON.stringify(true));
  82  |         });
  83  | 
  84  |         await page.reload();
  85  |     }
  86  | }
  87  | 
  88  | test.beforeEach(async ({ page }) => {
  89  |     await seedPlanner(page);
  90  | });
  91  | 
  92  | test("required actions can be completed and undone", async ({ page }) => {
  93  |     await page.locator(".bottom-nav-item").filter({ hasText: "Plan" }).click();
  94  | 
  95  |     await expect(page.locator(".saved-title").filter({ hasText: "Pay Rent" })).toBeVisible();
  96  | 
  97  |     const markPaidButton = page.getByRole("button", { name: /Mark Paid/i }).first();
  98  | 
  99  |     await expect(markPaidButton).toBeVisible();
  100 | 
  101 |     await markPaidButton.click();
  102 | 
  103 |     const completedSectionButton = page
  104 |         .getByRole("button")
  105 |         .filter({ hasText: /Completed This Cycle/i })
  106 |         .first();
  107 | 
  108 |     await completedSectionButton.click();
  109 | 
  110 |     const undoButton = page.getByRole("button", { name: /Undo/i }).first();
  111 | 
  112 |     await expect(undoButton).toBeVisible();
  113 | 
  114 |     await undoButton.click();
  115 | 
  116 |     await expect(
  117 |         page.getByRole("button", { name: /Mark Paid/i }).first()
  118 |     ).toBeVisible();
  119 | });
  120 | 
  121 | test("recommended actions render", async ({ page }) => {
> 122 |     await page.locator(".bottom-nav-item").filter({ hasText: "Plan" }).click();
      |                                                                        ^ Error: locator.click: Test timeout of 30000ms exceeded.
  123 | 
  124 |     await page.getByText("Recommended Actions").first().click();
  125 | 
  126 |     await expect(
  127 |         page.getByText(/Emergency Fund|Visa/i).first()
  128 |     ).toBeVisible();
  129 | });
  130 | 
  131 | test("payoff section renders seeded debt", async ({ page }) => {
  132 |     await page.getByRole("button", { name: /Payoff/i }).click();
  133 | 
  134 |     await expect(page.getByText("Visa")).toBeVisible();
  135 |     await expect(page.getByText("$500.00")).toBeVisible();
  136 | });
  137 | 
  138 | test("goals section renders seeded goal", async ({ page }) => {
  139 |     await page.getByRole("button", { name: /Goals/i }).click();
  140 | 
  141 |     await expect(
  142 |         page.locator(".saved-title").filter({ hasText: "Emergency Fund" })
  143 |     ).toBeVisible();
  144 | 
  145 |     await expect(page.getByText(/Saved \$200\.00/)).toBeVisible();
  146 | });
  147 | 
  148 | test("dark mode persists", async ({ page }) => {
  149 |     await page.getByRole("button", { name: /Dark Mode/i }).click();
  150 | 
  151 |     await page.waitForTimeout(300);
  152 | 
  153 |     const storedValue = await page.evaluate(() => {
  154 |         return localStorage.getItem("debtPlanner.darkMode");
  155 |     });
  156 | 
  157 |     expect(storedValue).toBe("true");
  158 | 
  159 |     await page.reload();
  160 | 
  161 |     await page.waitForTimeout(300);
  162 | 
  163 |     const restoredValue = await page.evaluate(() => {
  164 |         return localStorage.getItem("debtPlanner.darkMode");
  165 |     });
  166 | 
  167 |     expect(restoredValue).toBe("true");
  168 | });
  169 | 
  170 | 
```