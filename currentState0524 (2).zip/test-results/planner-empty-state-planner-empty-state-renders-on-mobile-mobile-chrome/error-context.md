# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: planner-empty-state.spec.ts >> planner empty state renders on mobile
- Location: tests\e2e\planner-empty-state.spec.ts:33:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('Required Actions').first()
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByText('Required Actions').first()

```

```yaml
- main:
  - heading "Debt Planner" [level=1]
  - paragraph: Enter a paycheck and see exactly what to do next.
  - button "Dark Mode"
  - navigation:
    - button "🏠 Plan"
    - button "💳 Bills"
    - button "📈 Payoff"
    - button "🎯 Goals"
  - button "Plan Settings"
  - heading "Plan Settings" [level=2]
  - paragraph: Enter your paycheck amount to create your first plan.
  - text: First Time Setup
  - heading "Paycheck" [level=2]
  - text: Paycheck Amount
  - 'textbox "Example: 1000"'
  - text: Pay Cycle
  - combobox:
    - option "Weekly"
    - option "Bi-Weekly" [selected]
    - option "Semi-Monthly"
    - option "Monthly"
  - text: Next Paycheck Date
  - textbox: 2026-06-07
  - paragraph: "Current plan date: 2026-05-24 Plan covers items due before 2026-06-07."
  - button "Calculate plan"
- alert
```

# Test source

```ts
  1  | import { expect, test, type Page } from "@playwright/test";
  2  | 
  3  | async function resetApp(page: Page) {
  4  |     await page.goto("/");
  5  | 
  6  |     await page.evaluate(() => {
  7  |         localStorage.clear();
  8  | 
  9  |         localStorage.setItem("debtPlanner.amount", JSON.stringify("1950"));
  10 |         localStorage.setItem("debtPlanner.payCycle", JSON.stringify("biweekly"));
  11 |         localStorage.setItem("debtPlanner.currentDate", JSON.stringify("2026-05-23"));
  12 |         localStorage.setItem("debtPlanner.requiredExpenses", JSON.stringify([]));
  13 |         localStorage.setItem("debtPlanner.debts", JSON.stringify([]));
  14 |         localStorage.setItem("debtPlanner.goals", JSON.stringify([]));
  15 |         localStorage.setItem("debtPlanner.completedRecommendedActions", JSON.stringify([]));
  16 |         localStorage.setItem("debtPlanner.payoffStrategy", JSON.stringify("snowball"));
  17 |         localStorage.setItem("debtPlanner.darkMode", JSON.stringify(false));
  18 |     });
  19 | 
  20 |     await page.reload();
  21 | 
  22 |     const setupOverlay = page.locator(".settings-overlay");
  23 | 
  24 |     if (await setupOverlay.isVisible().catch(() => false)) {
  25 |         await page.getByRole("button", { name: /Calculate plan/i }).click();
  26 |     }
  27 | }
  28 | 
  29 | test.beforeEach(async ({ page }) => {
  30 |     await resetApp(page);
  31 | });
  32 | 
  33 | test("planner empty state renders on mobile", async ({ page }) => {
  34 | await expect(
  35 | page.getByRole("heading", { name: "Debt Planner" })
  36 | ).toBeVisible();
  37 | 
  38 | await expect(
  39 | page.getByText("Required Actions").first()
> 40 | ).toBeVisible();
     |   ^ Error: expect(locator).toBeVisible() failed
  41 | 
  42 | await expect(
  43 | page.getByText("Recommended Actions").first()
  44 | ).toBeVisible();
  45 | 
  46 | await expect(
  47 | page.getByText("You're caught up for this paycheck")
  48 | ).toBeVisible();
  49 | });
  50 | 
  51 | test("bottom navigation switches sections", async ({ page }) => {
  52 |     await page.getByRole("button", { name: /Bills/i }).click();
  53 | 
  54 |     await expect(
  55 |         page.getByRole("button", { name: /Expenses/i })
  56 |     ).toBeVisible();
  57 | 
  58 |     await page.getByRole("button", { name: /Expenses/i }).click();
  59 | 
  60 |     await expect(
  61 |         page.getByRole("heading", { name: "Required Expenses" })
  62 |     ).toBeVisible();
  63 | 
  64 |     await page.getByRole("button", { name: /Payoff/i }).click();
  65 | 
  66 |     await expect(
  67 |         page.getByRole("heading", { name: "Debt Payoff Plan" })
  68 |     ).toBeVisible();
  69 | 
  70 |     await page.getByRole("button", { name: /Goals/i }).click();
  71 | 
  72 |     await expect(
  73 |         page.getByRole("heading", { name: "Goals" })
  74 |     ).toBeVisible();
  75 | 
  76 |     await page.getByRole("button", { name: /Plan/i }).click();
  77 | 
  78 |     await expect(
  79 |         page.getByRole("button", { name: /Recommended Actions/i })
  80 |     ).toBeVisible();
  81 | });
  82 | 
  83 | test("plan settings opens", async ({ page }) => {
  84 |     await page.getByRole("button", { name: "Plan Settings" }).click();
  85 | 
  86 |     await expect(
  87 |         page.getByRole("heading", { name: "Plan Settings" })
  88 |     ).toBeVisible();
  89 | });
  90 | 
```