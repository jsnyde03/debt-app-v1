import { expect, test, type Page } from "@playwright/test";

async function seedPopulatedPlanner(page: Page) {
await page.goto("/");

await page.evaluate(() => {
localStorage.clear();

localStorage.setItem("debtPlanner.amount", JSON.stringify("1950"));
localStorage.setItem("debtPlanner.payCycle", JSON.stringify("biweekly"));
localStorage.setItem("debtPlanner.currentDate", JSON.stringify("2026-05-23"));
localStorage.setItem("debtPlanner.semiMonthlyFirstDay", JSON.stringify("1"));
localStorage.setItem("debtPlanner.semiMonthlySecondDay", JSON.stringify("15"));
localStorage.setItem("debtPlanner.monthlyPayDay", JSON.stringify("1"));

localStorage.setItem(
"debtPlanner.requiredExpenses",
JSON.stringify([
{
id: "cell-phone",
name: "Cell Phone",
amount: 330.41,
dueDate: "2026-05-22",
originalDueDate: "2026-05-22",
recurrence: "monthly",
isPaidThisCycle: false,
},
{
id: "capcut",
name: "CapCut",
amount: 20,
dueDate: "2026-05-26",
originalDueDate: "2026-05-26",
recurrence: "monthly",
isPaidThisCycle: false,
},
{
id: "groceries",
name: "Groceries",
amount: 250,
dueDate: "2026-05-30",
originalDueDate: "2026-05-30",
recurrence: "per-paycheck",
isPaidThisCycle: false,
},
])
);

localStorage.setItem(
"debtPlanner.debts",
JSON.stringify([
{
id: "paypal-underground",
name: "PayPal - Underground Figures",
balance: 600,
originalBalance: 600,
minimumPayment: 30.15,
apr: 24.99,
dueDate: "2026-05-19",
originalDueDate: "2026-05-19",
type: "debt",
recurrence: "monthly",
isPaidThisCycle: false,
minimumPaidThisCycle: false,
snowballPaidThisCycle: false,
},
{
id: "klarna-arbys",
name: "Klarna - Arby's",
balance: 56.09,
originalBalance: 56.09,
minimumPayment: 18.7,
apr: 0,
dueDate: "2026-05-28",
originalDueDate: "2026-05-28",
type: "bnpl",
recurrence: "monthly",
isPaidThisCycle: false,
minimumPaidThisCycle: false,
snowballPaidThisCycle: false,
},
{
id: "capital-one",
name: "Capital One Platinum",
balance: 1420,
originalBalance: 1420,
minimumPayment: 75,
apr: 29.99,
dueDate: "2026-05-31",
originalDueDate: "2026-05-31",
type: "debt",
recurrence: "monthly",
isPaidThisCycle: false,
minimumPaidThisCycle: false,
snowballPaidThisCycle: false,
},
{
id: "affirm-long-name",
name: "Affirm - Very Long Mobile Wrapping Test Purchase",
balance: 315.44,
originalBalance: 315.44,
minimumPayment: 42.5,
apr: 15.99,
dueDate: "2026-06-02",
originalDueDate: "2026-06-02",
type: "bnpl",
recurrence: "monthly",
isPaidThisCycle: false,
minimumPaidThisCycle: false,
snowballPaidThisCycle: false,
},
])
);

localStorage.setItem(
"debtPlanner.goals",
JSON.stringify([
{
id: "emergency",
name: "Emergency Fund",
targetAmount: 1000,
currentAmount: 250,
originalCurrentAmount: 250,
type: "emergency",
},
{
id: "car-repair",
name: "Car Repair Buffer",
targetAmount: 750,
currentAmount: 100,
originalCurrentAmount: 100,
type: "savings",
},
])
);

localStorage.setItem(
"debtPlanner.completedRecommendedActions",
JSON.stringify([])
);

localStorage.setItem("debtPlanner.payoffStrategy", JSON.stringify("snowball"));
localStorage.setItem("debtPlanner.darkMode", JSON.stringify(false));
});

await page.reload();

const overlay = page.locator(".settings-overlay");

if (await overlay.isVisible().catch(() => false)) {
const paycheckInput = page.getByPlaceholder("Example: 1000");

if (await paycheckInput.isVisible().catch(() => false)) {
await paycheckInput.fill("1950");
}

await page.getByRole("button", { name: /Calculate plan/i }).click();
}
}

async function screenshot(page: Page, name: string) {
await page.screenshot({
path: `test-results/visual-state/${name}.png`,
fullPage: true,
});
}

test.beforeEach(async ({ page }) => {
await seedPopulatedPlanner(page);
});

test("capture populated mobile state screenshots", async ({ page }) => {
await expect(
page.getByRole("heading", { name: "Debt Planner" })
).toBeVisible();

await screenshot(page, "01-plan-populated");

await page.getByText("Recommended Actions").first().click();
await screenshot(page, "02-plan-recommended-expanded");

const firstMarkPaid = page.getByRole("button", { name: /Mark Paid/i }).first();

if (await firstMarkPaid.isVisible().catch(() => false)) {
await firstMarkPaid.click();
}

await page.getByText("Completed This Cycle").first().click();
await screenshot(page, "03-plan-completed-expanded");

await page.getByRole("button", { name: /Bills/i }).click();
await page.getByRole("button", { name: /Expenses/i }).click();
await screenshot(page, "04-bills-expenses-populated");

await page.getByRole("button", { name: /Bills/i }).click();
await page.getByRole("button", { name: /Debts/i }).click();
await screenshot(page, "05-bills-debts-populated");

await page.getByRole("button", { name: /Payoff/i }).click();
await screenshot(page, "06-payoff-populated");

await page.getByRole("button", { name: /Goals/i }).click();
await screenshot(page, "07-goals-populated");

await page.getByRole("button", { name: /Dark Mode/i }).click();
await screenshot(page, "08-dark-mode-current-tab");

await page.locator(".bottom-nav-item").filter({ hasText: "Plan" }).click();
await screenshot(page, "09-dark-mode-plan-populated");
});
