import { expect, test, type Page } from "@playwright/test";

async function resetApp(page: Page) {
    await page.goto("/");

    await page.evaluate(() => {
        localStorage.clear();

        localStorage.setItem("debtPlanner.amount", JSON.stringify("1950"));
        localStorage.setItem("debtPlanner.payCycle", JSON.stringify("biweekly"));
        localStorage.setItem("debtPlanner.currentDate", JSON.stringify("2026-05-23"));
        localStorage.setItem("debtPlanner.requiredExpenses", JSON.stringify([]));
        localStorage.setItem("debtPlanner.debts", JSON.stringify([]));
        localStorage.setItem("debtPlanner.goals", JSON.stringify([]));
        localStorage.setItem("debtPlanner.completedRecommendedActions", JSON.stringify([]));
        localStorage.setItem("debtPlanner.payoffStrategy", JSON.stringify("snowball"));
        localStorage.setItem("debtPlanner.darkMode", JSON.stringify(false));
    });

    await page.reload();

    const setupOverlay = page.locator(".settings-overlay");

    if (await setupOverlay.isVisible().catch(() => false)) {
        await page.getByRole("button", { name: /Calculate plan/i }).click();
    }
}

test.beforeEach(async ({ page }) => {
    await resetApp(page);
});

test("planner empty state renders on mobile", async ({ page }) => {
await expect(
page.getByRole("heading", { name: "Debt Planner" })
).toBeVisible();

await expect(
page.getByText("Required Actions").first()
).toBeVisible();

await expect(
page.getByText("Recommended Actions").first()
).toBeVisible();

await expect(
page.getByText("You're caught up for this paycheck")
).toBeVisible();
});

test("bottom navigation switches sections", async ({ page }) => {
    await page.getByRole("button", { name: /Bills/i }).click();

    await expect(
        page.getByRole("button", { name: /Expenses/i })
    ).toBeVisible();

    await page.getByRole("button", { name: /Expenses/i }).click();

    await expect(
        page.getByRole("heading", { name: "Required Expenses" })
    ).toBeVisible();

    await page.getByRole("button", { name: /Payoff/i }).click();

    await expect(
        page.getByRole("heading", { name: "Debt Payoff Plan" })
    ).toBeVisible();

    await page.getByRole("button", { name: /Goals/i }).click();

    await expect(
        page.getByRole("heading", { name: "Goals" })
    ).toBeVisible();

    await page.getByRole("button", { name: /Plan/i }).click();

    await expect(
        page.getByRole("button", { name: /Recommended Actions/i })
    ).toBeVisible();
});

test("plan settings opens", async ({ page }) => {
    await page.getByRole("button", { name: "Plan Settings" }).click();

    await expect(
        page.getByRole("heading", { name: "Plan Settings" })
    ).toBeVisible();
});
