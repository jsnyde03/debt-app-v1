import Purchases from "react-native-purchases";

const REVENUECAT_API_KEY = "appl_XUWODZnbbJFPbdMTgBTyKNAGGyp";

export async function initializeRenenueCat() {
    try {
        await Purchases.configure({
            apiKey: REVENUECAT_API_KEY,
        });
    } catch (error) {
        console.error("RevenueCat init failed", error);
    }
}

export async function getSubscriptionPlan(): Promise<"free" | "premium"> {
    try {
        const customerInfo = await Purchases.getCustomerInfo();

        const isPremiumActive = customerInfo.entitlements.active["premium"];

        return isPremiumActive ? "premium" : "free";
    } catch (error) {
        console.error("Failed to fetch subscription status", error);
        return "free";
    }
}

export async function purchasePremium() {
    try {
        const offerings = await Purchases.getOfferings();

        const current = offerings.current;

        if (!current || current.availablePackages.length === 0) {
            throw new Error("No RevenueCat packages found");
        }

        const purchaseResult = await Purchases.purchasePackage(current.availablePackages[0]);

        return purchaseResult.customerInfo.entitlements.active["premium"] ? "premium" : "free";
    } catch (error) {
        console.error("Purchase failed", error);
        return "free";
    }
}