import { useState } from "react";
import type { Debt } from "@/lib/storage/debtPlannerStorage";
import type { allocatePaycheck } from "@/lib/engine/allocatePaycheck";
import { projectDebtPayoff } from "@/lib/debt/projectDebtPayoff";
import { formatCurrency } from "@/lib/utils/formatCurrency";

type AllocationResult = ReturnType<typeof allocatePaycheck>;

type CompletedRecommendedAction = {
    targetId: string;
    label: string;
    category: "emergency" | "snowball" | "optional_goal";
    recommendedAmount: number;
    actualAmount: number;
};

type SnowballSectionProps = {
    debts: Debt[];
    result: AllocationResult | null;
    completedRecommendedActions: CompletedRecommendedAction[];
    payoffStrategy: "snowball" | "avalanche";
    setPayoffStrategy: React.Dispatch<
        React.SetStateAction<"snowball" | "avalanche">
    >;
};

export function SnowballSection({
    debts,
    result,
    completedRecommendedActions,
    payoffStrategy,
    setPayoffStrategy,
}: SnowballSectionProps) {
    const payoffOrder = [...debts]
        .filter((debt) => debt.balance > 0)
        .sort((a, b) => {
            if (payoffStrategy === "avalanche") {
                return b.apr - a.apr;
            }

            return a.balance - b.balance;
        });

    const snowballAllocations =
        result?.allocations.filter((item) => item.category === "snowball") ?? [];

    const currentTarget = payoffOrder[0];

    const completedSnowballExtra = completedRecommendedActions
        .filter((action) => action.category === "snowball")
        .reduce((sum, action) => sum + action.actualAmount, 0);

    const remainingSnowballExtra = snowballAllocations.reduce((sum, item) => {
        const completedForItem = completedRecommendedActions
            .filter(
                (action) =>
                    action.category === "snowball" &&
                    action.targetId === item.targetId &&
                    action.label === item.label
            )
            .reduce(
                (completedSum, action) => completedSum + action.actualAmount,
                0
            );

        return sum + Math.max(0, item.amount - completedForItem);
    }, 0);

    const debtsAfterCompletedPayments = debts.map((debt) => {
        const completedAmountForDebt = completedRecommendedActions
            .filter(
                (action) =>
                    action.category === "snowball" &&
                    action.targetId === debt.id
            )
            .reduce((sum, action) => sum + action.actualAmount, 0);

        return {
            ...debt,
            balance: Math.max(0, debt.balance - completedAmountForDebt),
        };
    });

    const baselineProjection = projectDebtPayoff({
        debts,
        monthlyExtraPayment: 0,
        strategy: payoffStrategy,
        startDate: new Date().toISOString().slice(0, 10),
    });

    const actualProjection = projectDebtPayoff({
        debts: debtsAfterCompletedPayments,
        monthlyExtraPayment: 0,
        strategy: payoffStrategy,
        startDate: new Date().toISOString().slice(0, 10),
    });

    const recommendedProjection = projectDebtPayoff({
        debts: debtsAfterCompletedPayments,
        monthlyExtraPayment: remainingSnowballExtra,
        strategy: payoffStrategy,
        startDate: new Date().toISOString().slice(0, 10),
    });

    const baselineCanBeEstimated =
        baselineProjection.estimatedDebtFreeDate !== "Unable to estimate";

    const actualCanBeEstimated =
        actualProjection.estimatedDebtFreeDate !== "Unable to estimate";

    const recommendedCanBeEstimated =
        recommendedProjection.estimatedDebtFreeDate !== "Unable to estimate";

    const actualInterestSaved =
        baselineCanBeEstimated && actualCanBeEstimated
            ? Math.max(
                0,
                baselineProjection.totalInterestPaid -
                actualProjection.totalInterestPaid
            )
            : null;

    const additionalRecommendedInterestSavings =
        actualCanBeEstimated && recommendedCanBeEstimated
            ? Math.max(
                0,
                actualProjection.totalInterestPaid -
                recommendedProjection.totalInterestPaid
            )
            : null;

    return (
        <section className="card">
            <h2>Debt Payoff Plan</h2>

            {!currentTarget ? (
                <p className="empty-state">No active debts added yet.</p>
            ) : (
                <>
                    <div className="snowball-target">
                        <p className="empty-state">Current Target</p>
                        <h3>{currentTarget.name}</h3>
                        <p>
                            Balance:{" "}
                            <strong>{formatCurrency(currentTarget.balance)}</strong>
                        </p>
                    </div>

                    <div className="payoff-strategy-selector">
                        <label>Payoff Strategy</label>

                        <div className="strategy-buttons">
                            <button
                                type="button"
                                className={
                                    payoffStrategy === "snowball"
                                        ? "strategy-button-active"
                                        : "strategy-button"
                                }
                                onClick={() => setPayoffStrategy("snowball")}
                            >
                                Snowball
                            </button>

                            <button
                                type="button"
                                className={
                                    payoffStrategy === "avalanche"
                                        ? "strategy-button-active"
                                        : "strategy-button"
                                }
                                onClick={() => setPayoffStrategy("avalanche")}
                            >
                                Avalanche
                            </button>
                        </div>

                        <p className="strategy-description">
                            {payoffStrategy === "snowball"
                                ? "Snowball prioritizes the smallest balance first for faster psychological wins."
                                : "Avalanche prioritizes the highest APR debts first to reduce long-term interest paid."}
                        </p>
                    </div>

                    <div className="debt-group">
                        <h3>Projected Payoff</h3>

                        <div className="saved-item">
                            <div>
                                <div className="saved-title">
                                    Actual Debt-Free Date
                                </div>
                                <div className="saved-meta">
                                    Based on minimum payments plus completed extra
                                    debt payments.
                                </div>
                            </div>

                            <div className="saved-amount">
                                {actualProjection.estimatedDebtFreeDate}
                            </div>
                        </div>

                        <div className="saved-item">
                            <div>
                                <div className="saved-title">
                                    If You Pay This Recommendation
                                </div>
                                <div className="saved-meta">
                                    Uses completed extra payments plus this
                                    paycheck&apos;s remaining recommended extra debt
                                    payment.
                                </div>
                            </div>

                            <div className="saved-amount">
                                {recommendedProjection.estimatedDebtFreeDate}
                            </div>
                        </div>

                        <div className="saved-item">
                            <div>
                                <div className="saved-title">
                                    Completed Extra Debt Payments
                                </div>
                                <div className="saved-meta">
                                    Extra payments already marked paid this cycle.
                                </div>
                            </div>

                            <div className="saved-amount">
                                {formatCurrency(completedSnowballExtra)}
                            </div>
                        </div>

                        <div className="saved-item">
                            <div>
                                <div className="saved-title">
                                    Recommended Extra Still Available
                                </div>
                                <div className="saved-meta">
                                    Extra amount still suggested this paycheck.
                                </div>
                            </div>

                            <div className="saved-amount">
                                {formatCurrency(remainingSnowballExtra)}
                            </div>
                        </div>

                        <div className="saved-item">
                            <div>
                                <div className="saved-title">
                                    Estimated Interest Paid
                                </div>
                                <div className="saved-meta">
                                    Based on completed extra payments only.
                                </div>
                            </div>

                            <div className="saved-amount">
                                {actualCanBeEstimated
                                    ? formatCurrency(actualProjection.totalInterestPaid)
                                    : "Unable to be estimated" }
                            </div>
                        </div>

                        <div className="saved-item">
                            <div>
                                <div className="saved-title">
                                    Interest Saved So Far
                                </div>
                                <div className="saved-meta">
                                    Compared with minimum payments only.
                                </div>
                            </div>

                            <div className="saved-amount">
                                {actualInterestSaved === null
                                    ? "Unable to estimate"
                                    : formatCurrency(actualInterestSaved)}
                            </div>
                        </div>

                        <div className="saved-item">
                            <div>
                                <div className="saved-title">
                                    Additional Interest Savings Available
                                </div>
                                <div className="saved-meta">
                                    Extra interest savings if you pay the current
                                    recommendation.
                                </div>
                            </div>

                            <div className="saved-amount">
                                {additionalRecommendedInterestSavings === null
                                    ? "Unable to estimate"
                                    : formatCurrency(
                                        additionalRecommendedInterestSavings
                                    )}
                            </div>
                        </div>
                    </div>

                    <div className="debt-group">
                        <h3>Payoff Order</h3>

                        {payoffOrder.map((debt, index) => (
                            <div key={debt.id} className="saved-item">
                                <div>
                                    <div className="saved-title">
                                        #{index + 1} {debt.name}
                                    </div>

                                    <div className="saved-meta">
                                        Balance {formatCurrency(debt.balance)} · Min{" "}
                                        {formatCurrency(debt.minimumPayment)} · APR{" "}
                                        {debt.apr}%
                                    </div>
                                </div>

                                <div className="saved-amount">
                                    {formatCurrency(debt.balance)}
                                </div>
                            </div>
                        ))}
                    </div>
                </>
            )}
        </section>
    );
}
