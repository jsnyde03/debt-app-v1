import { useState } from "react";
import type { allocatePaycheck } from "@/lib/engine/allocatePaycheck";
import type { Debt, RequiredExpense } from "@/lib/storage/debtPlannerStorage";
import { formatCurrency } from "@/lib/utils/formatCurrency";

type AllocationResult = ReturnType<typeof allocatePaycheck>;

type Goal = {
    id: string;
    name: string;
    targetAmount: number;
    currentAmount: number;
    type: "emergency" | "savings";
};

type RecommendedCategory = "emergency" | "snowball" | "optional_goal";

type CompletedRecommendedAction = {
    targetId: string;
    label: string;
    category: RecommendedCategory;
    recommendedAmount: number;
    actualAmount: number;
};

type ResultsSectionProps = {
    result: AllocationResult | null;
    requiredExpenses: RequiredExpense[];
    debts: Debt[];
    goals: Goal[];
    completedRecommendedActions: CompletedRecommendedAction[];
    currentDate: string;
    onMarkExpensePaid: (id: string) => void;
    onMarkDebtMinimumPaid: (id: string) => void;
    onMarkDebtSnowballPaid: (id: string) => void;
    onMarkRecommendedAction: (
        targetId: string,
        label: string,
        category: RecommendedCategory,
        recommendedAmount: number,
        actualAmount: number
    ) => void;
};

function isOverdue(dueDate: string, currentDate: string) {
    return new Date(`${dueDate}T00:00:00`) < new Date(`${currentDate}T00:00:00`);
}

function isRecommendedCategory(
    category: string
): category is RecommendedCategory {
    return (
        category === "emergency" ||
        category === "snowball" ||
        category === "optional_goal"
    );
}

export function ResultsSection({
    result,
    requiredExpenses,
    debts,
    goals,
    completedRecommendedActions,
    currentDate,
    onMarkExpensePaid,
    onMarkDebtMinimumPaid,
    onMarkRecommendedAction,
}: ResultsSectionProps) {
    const [editingRecommendedKey, setEditingRecommendedKey] = useState<string | null>(
        null
    );

    const [editedRecommendedAmounts, setEditedRecommendedAmounts] = useState<
        Record<string, string>
    >({});

    const [recommendedAmountErrors, setRecommendedAmountErrors] = useState<
        Record<string, string>
    >({});

    if (!result) {
        return null;
    }

    const requiredActions = result.allocations.filter(
        (item) => item.category === "expense" || item.category === "minimum_debt"
    );

    const recommendedActions = result.allocations.filter(
        (item) => item.category === "emergency" || item.category === "snowball"
    );

    const optionalGoalActions = result.allocations.filter(
        (item) => item.category === "optional_goal"
    );

    const bufferActions = result.allocations.filter(
        (item) => item.category === "leftover" && item.label === "Keep cash buffer"
    );

    const bufferTotal = bufferActions.reduce((sum, item) => sum + item.amount, 0);

    const requiredTotal = requiredActions.reduce(
        (sum, item) => sum + item.amount,
        0
    );

    const completedRecommendedTotal = completedRecommendedActions.reduce(
        (sum, action) => sum + action.actualAmount,
        0
    );

    const allSuggestedActions = [...recommendedActions, ...optionalGoalActions];

    const remainingRecommendedTotal = allSuggestedActions.reduce((sum, item) => {
        const completedForItem = completedRecommendedActions
            .filter(
                (action) =>
                    action.targetId === item.targetId &&
                    action.label === item.label &&
                    action.category === item.category
            )
            .reduce((completedSum, action) => completedSum + action.actualAmount, 0);

        return sum + Math.max(0, item.amount - completedForItem);
    }, 0);

    const flexibleCashAvailable =
        result.paycheckAmount -
        requiredTotal -
        bufferTotal -
        completedRecommendedTotal;

    const hasOverdueItems = requiredActions.some((item) => {
        const expense = requiredExpenses.find((expense) => expense.id === item.targetId);
        const debt = debts.find((debt) => debt.id === item.targetId);
        const dueDate = expense?.dueDate ?? debt?.dueDate;

        return dueDate
            ? isOverdue(dueDate, currentDate)
            : false;
    })

    function getRecommendedKey(item: {
        category: string;
        targetId?: string;
        label: string;
    }) {
        return `${item.category}-${item.targetId ?? "none"}-${item.label}`;
    }

    function getCompletedAction(item: {
        category: string;
        targetId?: string;
        label: string;
    }) {
        return completedRecommendedActions.find(
            (action) =>
                action.targetId === item.targetId &&
                action.label === item.label &&
                action.category === item.category
        );
    }

    function getActualAmount(item: { amount: number; category: string; targetId?: string; label: string }) {
        const key = getRecommendedKey(item);
        const editedAmount = editedRecommendedAmounts[key];

        if (editedAmount === undefined || editedAmount === "") {
            return item.amount;
        }

        return Number(editedAmount);
    }

    function getRemainingDebtBalance(targetId?: string) {
        if (!targetId) {
            return null;
        }

        const debt = debts.find((item) => item.id === targetId);

        if (!debt) {
            return null;
        }

        const completedForDebt = completedRecommendedActions
            .filter(
                (action) =>
                    action.category === "snowball" && action.targetId === targetId
            )
            .reduce((sum, action) => sum + action.actualAmount, 0);

        return Math.max(0, debt.balance - completedForDebt);
    }

    function getRemainingGoalAmount(targetId?: string) {
        if (!targetId) {
            return null;
        }

        const goal = goals.find((item) => item.id === targetId);

        if (!goal) {
            return null;
        }

        const completedForGoal = completedRecommendedActions
            .filter(
                (action) =>
                    (action.category === "emergency" ||
                        action.category === "optional_goal") &&
                    action.targetId === targetId
            )
            .reduce((sum, action) => sum + action.actualAmount, 0);

        return Math.max(0, goal.targetAmount - goal.currentAmount - completedForGoal);
    }

    function renderRecommendedAction(item: (typeof result.allocations)[number]) {
        const key = getRecommendedKey(item);
        const completed = getCompletedAction(item);
        const actualAmount = getActualAmount(item);
        const displayAmount = completed?.actualAmount ?? actualAmount;

        return (
            <div
                key={key}
                className={completed ? "saved-item completed-action" : "saved-item"}
            >
                <div>
                    <div className="saved-title">{item.label}</div>

                    <div className="saved-meta">
                        {item.category === "emergency"
                            ? "Emergency Fund Contribution"
                            : item.category === "optional_goal"
                                ? "Optional Goal Contribution"
                                : "Extra Debt Payment"}
                    </div>

                    {!completed &&
                        (editingRecommendedKey === key ? (
                            <input
                                type="text"
                                inputMode="decimal"
                                value={editedRecommendedAmounts[key] ?? item.amount}
                                onChange={(event) =>
                                    setEditedRecommendedAmounts((current) => ({
                                        ...current,
                                        [key]: event.target.value,
                                    }))
                                }
                                className="amount-edit-input"
                            />
                        ) : (
                            <button
                                type="button"
                                className="secondary-button"
                                onClick={() => setEditingRecommendedKey(key)}
                            >
                                Edit Amount
                            </button>
                        ))}

                    {recommendedAmountErrors[key] && (
                        <p className="validation-error">
                            {recommendedAmountErrors[key]}
                        </p>
                    )}
                </div>

                <strong>{formatCurrency(displayAmount)}</strong>

                <button
                    type="button"
                    className={
                        completed
                            ? "secondary-button completed-action"
                            : "secondary-button"
                    }
                    onClick={() => {
                        const category = item.category;

                        if (!isRecommendedCategory(category)) {
                            return;
                        }

                        if (!item.targetId) {
                            return;
                        }

                        if (completed) {
                            setRecommendedAmountErrors((current) => ({
                                ...current,
                                [key]: "",
                            }));

                            onMarkRecommendedAction(
                                item.targetId,
                                item.label,
                                category,
                                item.amount,
                                completed.actualAmount
                            );

                            setEditingRecommendedKey(null);
                            return;
                        }

                        const amountToApply = getActualAmount(item);

                        if (amountToApply < 0) {
                            setRecommendedAmountErrors((current) => ({
                                ...current,
                                [key]: "Amount cannot be negative.",
                            }));
                            return;
                        }

                        if (amountToApply > item.amount) {
                            setRecommendedAmountErrors((current) => ({
                                ...current,
                                [key]: `You're paying more than recommended. Recommended: ${formatCurrency(
                                    item.amount
                                )}.`,
                            }));
                            return;
                        }

                        if (amountToApply > flexibleCashAvailable) {
                            setRecommendedAmountErrors((current) => ({
                                ...current,
                                [key]: "Amount exceeds flexible cash.",
                            }));
                            return;
                        }

                        if (category === "snowball") {
                            const remainingDebtBalance = getRemainingDebtBalance(
                                item.targetId
                            );

                            if (
                                remainingDebtBalance !== null &&
                                amountToApply > remainingDebtBalance
                            ) {
                                setRecommendedAmountErrors((current) => ({
                                    ...current,
                                    [key]: `Amount exceeds remaining debt balance of ${formatCurrency(
                                        remainingDebtBalance
                                    )}.`,
                                }));
                                return;
                            }
                        }

                        if (
                            category === "emergency" ||
                            category === "optional_goal"
                        ) {
                            const remainingGoalAmount = getRemainingGoalAmount(
                                item.targetId
                            );

                            if (
                                remainingGoalAmount !== null &&
                                amountToApply > remainingGoalAmount
                            ) {
                                setRecommendedAmountErrors((current) => ({
                                    ...current,
                                    [key]: `Amount exceeds remaining goal amount of ${formatCurrency(
                                        remainingGoalAmount
                                    )}.`,
                                }));
                                return;
                            }
                        }

                        setRecommendedAmountErrors((current) => ({
                            ...current,
                            [key]: "",
                        }));

                        onMarkRecommendedAction(
                            item.targetId,
                            item.label,
                            category,
                            item.amount,
                            amountToApply
                        );

                        setEditingRecommendedKey(null);
                    }}
                >
                    {completed
                        ? "Undo"
                        : item.category === "emergency" ||
                            item.category === "optional_goal"
                            ? "Mark Saved"
                            : "Mark Paid"}
                </button>
            </div>
        );
    }

    return (
        <>
            <section className="card">
                <h2>Required Actions</h2>

                {requiredActions.length === 0 ? (
                    <p className="empty-state">
                        No required expenses or debt minimums due this pay cycle.
                    </p>
                ) : (
                    requiredActions.map((item, index) => {
                        const expense =
                            item.category === "expense"
                                ? requiredExpenses.find(
                                    (expenseItem) =>
                                        expenseItem.id === item.targetId
                                )
                                : undefined;

                        const debt =
                            item.category === "minimum_debt"
                                ? debts.find(
                                    (debtItem) =>
                                        debtItem.id ===
                                        (item.debtId ?? item.targetId)
                                )
                                : undefined;

                        const isPaid =
                            item.category === "expense"
                                ? expense?.isPaidThisCycle ?? false
                                : debt?.minimumPaidThisCycle ??
                                debt?.isPaidThisCycle ??
                                false;

                        const dueDate = expense?.dueDate ?? debt?.dueDate;
                        const overdue = dueDate
                            ? isOverdue(dueDate, currentDate)
                            : false;

                        return (
                            <div
                                key={`${item.category}-${item.targetId ?? index}`}
                                className={`saved-item ${isPaid ? "completed-item" : ""} ${overdue ? "overdue-item" : ""}`}
                                   
                                
                            >
                                <div>
                                    <div className="saved-title">
                                        {item.label}
                                    </div>
                                    {overdue && (
                                            <div className="overdue-badge">
                                                Overdue
                                            </div>
                                        )}
                                    

                                    <div className="saved-meta">
                                        {item.category === "expense"
                                            ? "Required Expense"
                                            : "Debt Minimum Payment"}
                                    </div>
                                </div>

                                <strong>{formatCurrency(item.amount)}</strong>

                                <button
                                    type="button"
                                    className={
                                        isPaid
                                            ? "secondary-button completed-action"
                                            : "secondary-button"
                                    }
                                    onClick={() => {
                                        if (item.category === "expense") {
                                            if (item.targetId) {
                                                onMarkExpensePaid(item.targetId);
                                            }

                                            return;
                                        }

                                        if (item.category === "minimum_debt") {
                                            const debtId =
                                                item.debtId ?? item.targetId;

                                            if (debtId) {
                                                onMarkDebtMinimumPaid(debtId);
                                            }
                                        }
                                    }}
                                >
                                    {isPaid ? "Undo" : "Mark Paid"}
                                </button>
                            </div>
                        );
                    })
                )}
            </section>

            <section className="card">
                <h2>Recommended Actions</h2>

                {recommendedActions.length === 0 ? (
                    <p className="empty-state">
                        No emergency fund or extra debt payment recommendation
                        available this pay cycle.
                    </p>
                ) : (
                    recommendedActions.map((item) => renderRecommendedAction(item))
                )}
            </section>

            {optionalGoalActions.length > 0 && (
                <section className="card">
                    <h2>Optional Goals</h2>
                    <p className="empty-state">
                        These are optional savings contributions after required
                        payments and debt payoff recommendations.
                    </p>

                    {optionalGoalActions.map((item) =>
                        renderRecommendedAction(item)
                    )}
                </section>
            )}

            <section className="card">
                <h2>Flexible Cash</h2>

                <div className="saved-item">
                    <div>
                        <div className="saved-title">
                            Available Flexible Cash
                        </div>

                        <div className="saved-meta">
                            Buffer: {formatCurrency(bufferTotal)} · Completed
                            Recommendations:{" "}
                            {formatCurrency(completedRecommendedTotal)} ·
                            Remaining Suggested:{" "}
                            {formatCurrency(remainingRecommendedTotal)}
                        </div>
                    </div>

                    <div className="saved-amount">
                        {formatCurrency(flexibleCashAvailable)}
                    </div>
                </div>
            </section>

            <section className="card">
                <h2>Status</h2>

                {hasOverdueItems ? (
                    <p className="status-warning">
                        You have overdue payments that need immediate attention.
                    </p>
                ) : result.shortfall > 0 ? (
                    <p className="status-warning">
                        You're short by {formatCurrency(result.shortfall)} for required items this pay cycle.
                    </p>
                ) : (
                    <p className="status-good">
                        You're on track.
                    </p>
                )}
            </section>
        </>
    );
}
