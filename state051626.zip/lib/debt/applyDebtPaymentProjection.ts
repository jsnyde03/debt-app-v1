import { calculateMonthlyInterest } from "./calculateMonthlyInterest";

function roundMoney(amount: number) {
    return Math.round(amount * 100) / 100;
}

export function applyDebtPaymentProjection(params: {balance: number; apr: number; payment: number;}) {
    const interest = calculateMonthlyInterest(params.balance, params.apr);

    const projectedBalance = Math.max(0, roundMoney(params.balance + interest - params.payment));

    return {
        startingBalance: params.balance,
        interest,
        payment: params.payment,
        projectedBalance,
    }
}