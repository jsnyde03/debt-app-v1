import { allocatePaycheck } from "./allocatePaycheck.ts";

const result = allocatePaycheck({
	paycheckAmount: 500,
	currentDate: "2026-05-04",
	nextPaycheckDate: "2026-05-15",
	expenses: [
		{
			id: "1",
			name: "Rent",
			amount: 600,
			dueDate: "2026-05-06",
		},
		{
			id: "2",
			name: "Phone Bill",
			amount: 80,
			dueDate: "2026-05-12",
		},
	],
	debts: [
		{
			id: "1",
			name: "Credit Card",
			balance: 500,
			minimumPayment: 60,
			dueDate: "2026-05-10",
			type: "debt",
		},
		{
			id: "2",
			name: "Afterpay",
			balance: 120,
			minimumPayment: 30,
			dueDate: "2026-05-13",
			type: "bnpl",
		},
	],
	goals: [
		{
			id: "1",
			name: "Starter Emergency Fund",
			targetAmount: 500,
			currentAmount: 200,
			type: "emergency",
		}
	],
});

console.log("\nDo this now\n");

for (const item of result.allocations) {
	console.log(`- ${item.label}: $${item.amount}`);
}

console.log(`\nRemaining: $${result.remaining}`);
console.log(`\nRequired before next paycheck: $${result.totalRequired}`);

if (result.shortfall > 0) {
	console.log(`\nYou are short: $${result.shortfall}`);
	console.log("\nStill need to cover:");
	
	result.unfundedRequiredItems.forEach((item: any) => {
		console.log(`- ${item.label}: $${item.amount}`);
	});
} else {
	console.log("\nYou're on track.");
}
			
		