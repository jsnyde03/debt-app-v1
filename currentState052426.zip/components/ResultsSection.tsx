import { useState } from "react";
import type { allocatePaycheck } from "@/lib/engine/allocatePaycheck";
import type { Debt, RequiredExpense } from "@/lib/storage/debtPlannerStorage";
import { formatCurrency } from "@/lib/utils/formatCurrency";

type AllocationResult = ReturnType<typeof allocatePaycheck>;

type Goal = {
    id: string;
    name: string;
    targetAmount: number;
    currentAmount: number;
    type: "emergency" | "savings";
};

type RecommendedCategory =
    | "emergency"
    | "snowball"
    | "optional_goal";

type CompletedRecommendedAction = {
    targetId: string;
    label: string;
    category: RecommendedCategory;
    recommendedAmount: number;
    actualAmount: number;
};

type ResultsSectionProps = {
    result: AllocationResult | null;
    requiredExpenses: RequiredExpense[];
    debts: Debt[];
    goals: Goal[];
    completedRecommendedActions: CompletedRecommendedAction[];
    currentDate: string;
    onMarkExpensePaid: (id: string) => void;
    onMarkDebtMinimumPaid: (id: string) => void;
    onMarkDebtSnowballPaid: (id: string) => void;
    onMarkRecommendedAction: (
        targetId: string,
        label: string,
        category: RecommendedCategory,
        recommendedAmount: number,
        actualAmount: number
    ) => void;
};

function isOverdue(dueDate: string, currentDate: string) {
    return (
        new Date(`${dueDate}T00:00:00`) <
        new Date(`${currentDate}T00:00:00`)
    );
}

function isRecommendedCategory(
    category: string
): category is RecommendedCategory {
    return (
        category === "emergency" ||
        category === "snowball" ||
        category === "optional_goal"
    );
}

export function ResultsSection({
    result,
    requiredExpenses,
    debts,
    goals,
    completedRecommendedActions,
    currentDate,
    onMarkExpensePaid,
    onMarkDebtMinimumPaid,
    onMarkRecommendedAction,
}: ResultsSectionProps) {
    const [showAllRequiredActions, setShowAllRequiredActions] =
        useState(false);

    const [requiredExpanded, setRequiredExpanded] =
        useState(true);

    const [recommendedExpanded, setRecommendedExpanded] =
        useState(false);

    const [completedExpanded, setCompletedExpanded] =
        useState(false);

    const [showAllRecommendedActions, setShowAllRecommendedActions] =
        useState(false);

    const [editingRecommendedKey, setEditingRecommendedKey] =
        useState<string | null>(null);

    const [editedRecommendedAmounts, setEditedRecommendedAmounts] =
        useState<Record<string, string>>({});

    const [recommendedAmountErrors, setRecommendedAmountErrors] =
        useState<Record<string, string>>({});

    if (!result) {
        return null;
    }

    const requiredActions = result.allocations.filter(
        (item) =>
            item.category === "expense" ||
            item.category === "minimum_debt"
    );

    const recommendedActions = result.allocations.filter(
        (item) =>
            item.category === "emergency" ||
            item.category === "snowball"
    );

    const optionalGoalActions = result.allocations.filter(
        (item) => item.category === "optional_goal"
    );

    const unpaidRequiredActions = requiredActions.filter((item) => {
        const expense =
            item.category === "expense"
                ? requiredExpenses.find(
                    (expenseItem) =>
                        expenseItem.id === item.targetId
                )
                : undefined;

        const debt =
            item.category === "minimum_debt"
                ? debts.find(
                    (debtItem) =>
                        debtItem.id ===
                        (item.debtId ?? item.targetId)
                )
                : undefined;

        const isPaid =
            item.category === "expense"
                ? expense?.isPaidThisCycle ?? false
                : debt?.minimumPaidThisCycle ??
                debt?.isPaidThisCycle ??
                false;

        return !isPaid;
    });

    const completedRequiredActions = [
        ...requiredExpenses
            .filter((expense) => expense.isPaidThisCycle)
            .map((expense) => ({
                label: `Pay ${expense.name}`,
                amount: expense.amount,
                category: "expense" as const,
                targetId: expense.id,
            })),

        ...debts
            .filter((debt) => debt.minimumPaidThisCycle ?? debt.isPaidThisCycle)
            .map((debt) => ({
                label: `Pay minimum on ${debt.name}`,
                amount: debt.minimumPayment,
                category: "minimum_debt" as const,
                targetId: debt.id,
                debtId: debt.id,
            })),
    ];

    const visibleRequiredActions = showAllRequiredActions
        ? unpaidRequiredActions
        : unpaidRequiredActions.slice(0, 6);

    const hiddenRequiredCount = Math.max(
        0,
        unpaidRequiredActions.length -
        visibleRequiredActions.length
    );

    const visibleRecommendedActions =
        showAllRecommendedActions
            ? recommendedActions
            : recommendedActions.slice(0, 5);

    const hiddenRecommendedCount = Math.max(
        0,
        recommendedActions.length -
        visibleRecommendedActions.length
    );

    const bufferActions = result.allocations.filter(
        (item) =>
            item.category === "leftover" &&
            item.label === "Keep cash buffer"
    );

    const bufferTotal = bufferActions.reduce(
        (sum, item) => sum + item.amount,
        0
    );

    const requiredTotal = requiredActions.reduce(
        (sum, item) => sum + item.amount,
        0
    );

    const completedRecommendedTotal =
        completedRecommendedActions.reduce(
            (sum, action) => sum + action.actualAmount,
            0
        );

    const allSuggestedActions = [
        ...recommendedActions,
        ...optionalGoalActions,
    ];

    const remainingRecommendedTotal =
        allSuggestedActions.reduce((sum, item) => {
            const completedForItem =
                completedRecommendedActions
                    .filter(
                        (action) =>
                            action.targetId === item.targetId &&
                            action.label === item.label &&
                            action.category === item.category
                    )
                    .reduce(
                        (completedSum, action) =>
                            completedSum + action.actualAmount,
                        0
                    );

            return (
                sum +
                Math.max(
                    0,
                    item.amount - completedForItem
                )
            );
        }, 0);

    const flexibleCashAvailable =
        result.paycheckAmount -
        requiredTotal -
        bufferTotal -
        completedRecommendedTotal;

    const hasOverdueItems = requiredActions.some((item) => {
        const expense = requiredExpenses.find(
            (expense) => expense.id === item.targetId
        );

        const debt = debts.find(
            (debt) => debt.id === item.targetId
        );

        const dueDate =
            expense?.dueDate ?? debt?.dueDate;

        const isPaid =
            item.category === "expense"
                ? expense?.isPaidThisCycle ?? false
                : debt?.minimumPaidThisCycle ??
                debt?.isPaidThisCycle ??
                false;

        return dueDate && !isPaid
            ? isOverdue(dueDate, currentDate)
            : false;
    });

    function getRecommendedKey(item: {
        category: string;
        targetId?: string;
        label: string;
    }) {
        return `${item.category}-${item.targetId ?? "none"}-${item.label}`;
    }

    function getCompletedAction(item: {
        category: string;
        targetId?: string;
        label: string;
    }) {
        return completedRecommendedActions.find(
            (action) =>
                action.targetId === item.targetId &&
                action.label === item.label &&
                action.category === item.category
        );
    }

    function getActualAmount(item: {
        amount: number;
        category: string;
        targetId?: string;
        label: string;
    }) {
        const key = getRecommendedKey(item);

        const editedAmount =
            editedRecommendedAmounts[key];

        if (
            editedAmount === undefined ||
            editedAmount === ""
        ) {
            return item.amount;
        }

        return Number(editedAmount);
    }

    function renderRequiredAction(
        item: AllocationResult["allocations"][number],
        index: number
    ) {
        const expense =
            item.category === "expense"
                ? requiredExpenses.find(
                    (expenseItem) =>
                        expenseItem.id === item.targetId
                )
                : undefined;

        const debt =
            item.category === "minimum_debt"
                ? debts.find(
                    (debtItem) =>
                        debtItem.id ===
                        (item.debtId ?? item.targetId)
                )
                : undefined;

        const isPaid =
            item.category === "expense"
                ? expense?.isPaidThisCycle ?? false
                : debt?.minimumPaidThisCycle ??
                debt?.isPaidThisCycle ??
                false;

        const dueDate =
            expense?.dueDate ?? debt?.dueDate;

        const overdue =
            dueDate && !isPaid
                ? isOverdue(dueDate, currentDate)
                : false;

        return (
            <div
                key={`${item.category}-${item.targetId ?? index}`}
                className={["saved-item", isPaid ? "completed-item" : "", overdue ? "overdue-item" : "",].filter(Boolean).join(" ")}
            >
                <div className="saved-item-left">
                    <div className="saved-title">
                        {item.label}
                    </div>

                    {overdue && (
                        <div className="status-chip overdue">
                            Overdue
                        </div>
                    )}

                    <div className="saved-meta">
                        {dueDate
                            ? `Due ${dueDate}`
                            : "Required Payment"}
                    </div>
                </div>

                <div className="saved-item-right">
                    <strong className="saved-amount">
                        {formatCurrency(item.amount)}
                    </strong>

                    <button
                        type="button"
                        className={
                            isPaid
                                ? "action-pill completed"
                                : "action-pill"
                        }
                        onClick={() => {
                            if (item.category === "expense") {
                                if (item.targetId) {
                                    onMarkExpensePaid(item.targetId);
                                }

                                return;
                            }

                            if (
                                item.category === "minimum_debt"
                            ) {
                                const debtId =
                                    item.debtId ??
                                    item.targetId;

                                if (debtId) {
                                    onMarkDebtMinimumPaid(
                                        debtId
                                    );
                                }
                            }
                        }}
                    >
                        {isPaid ? "Undo" : "Mark Paid"}
                    </button>
                </div>
            </div>
        );
    }

    function renderRecommendedAction(
        item: AllocationResult["allocations"][number],
        options?: {
            isFocusTarget?: boolean;
        }
    ) {
        const key = getRecommendedKey(item);

        const completed =
            getCompletedAction(item);

        const actualAmount =
            getActualAmount(item);

        const displayAmount =
            completed?.actualAmount ??
            actualAmount;

        return (
            <div
                key={key}
                className={[
                    "saved-item",
                    "recommended-card",
                    options?.isFocusTarget ? "focus-target-card" : "",
                    completed ? "completed-action completed-item" : "",
                ].filter(Boolean).join(" ")
                }
            >
                <div className="saved-item-left">
                    <div className="saved-title">
                        {item.label}
                    </div>

                    <div className="saved-meta">
                        Suggested for this cycle
                    </div>

                    {recommendedAmountErrors[key] && (
                        <p className="validation-error">
                            {
                                recommendedAmountErrors[
                                key
                                ]
                            }
                        </p>
                    )}
                </div>

                <div className="saved-item-right">
                    <strong className="saved-amount">
                        {formatCurrency(displayAmount)}
                    </strong>

                    <button
                        type="button"
                        className={
                            completed
                                ? "action-pill completed"
                                : "action-pill"
                        }
                        onClick={() => {
                            const category =
                                item.category;

                            if (
                                !isRecommendedCategory(
                                    category
                                )
                            ) {
                                return;
                            }

                            if (!item.targetId) {
                                return;
                            }

                            onMarkRecommendedAction(
                                item.targetId,
                                item.label,
                                category,
                                item.amount,
                                actualAmount
                            );

                            setEditingRecommendedKey(
                                null
                            );
                        }}
                    >
                        {completed
                            ? "Undo"
                            : item.category ===
                                "emergency" ||
                                item.category ===
                                "optional_goal"
                                ? "Mark Saved"
                                : "Mark Paid"}
                    </button>
                </div>
            </div>
        );
    }

    return (
        <section className="card plan-dashboard">
            <div className="plan-dashboard-header">
                <div>
                    <h2>This Paycheck</h2>

                    <p
                        className={
                            hasOverdueItems ||
                                result.shortfall > 0
                                ? "status-warning"
                                : "status-good"
                        }
                    >
                        {hasOverdueItems
                            ? "You have overdue payments requiring attention."
                            : result.shortfall > 0
                                ? `You're short ${formatCurrency(result.shortfall)} this cycle.`
                                : "You're on track this cycle."}
                    </p>
                </div>
            </div>

            <div className="execution-summary-strip">
                <div>
                    <span>Required</span>
                    <strong>
                        {formatCurrency(requiredTotal)}
                    </strong>
                </div>

                <div>
                    <span>Recommended</span>
                    <strong>
                        {formatCurrency(
                            remainingRecommendedTotal
                        )}
                    </strong>
                </div>

                <div>
                    <span>Flexible Cash</span>
                    <strong>
                        {formatCurrency(
                            flexibleCashAvailable
                        )}
                    </strong>
                </div>

                <div>
                    <span>Status</span>
                    <strong>
                        {hasOverdueItems
                            ? "Overdue"
                            : result.shortfall > 0
                                ? "Short"
                                : "On Track"}
                    </strong>
                </div>
            </div>

            <div className="plan-dashboard-section">
                <button
                    type="button"
                    className="section-collapse-button"
                    onClick={() =>
                        setRequiredExpanded(
                            (current) => !current
                        )
                    }
                >
                    <div className="section-collapse-left">
                        <h2>
                            Required Actions
                        </h2>

                        <span className="section-count-pill">
                            {
                                unpaidRequiredActions.length
                            }
                        </span>
                    </div>

                    <span
                        className={
                            requiredExpanded
                                ? "collapse-chevron expanded"
                                : "collapse-chevron"
                        }
                    >
                        ▼
                    </span>
                </button>

                {requiredExpanded && (
                    <>
                        {unpaidRequiredActions.length ===
                            0 ? (
                            <p className="empty-state success-empty-state">
                                You&apos;re caught up for this paycheck.  No unpaid required actions remain.
                            </p>
                        ) : (
                            visibleRequiredActions.map(
                                (item, index) =>
                                    renderRequiredAction(
                                        item,
                                        index
                                    )
                            )
                        )}

                        {hiddenRequiredCount > 0 && (
                            <button
                                type="button"
                                className="text-action-button show-more-inline"
                                onClick={() =>
                                    setShowAllRequiredActions(
                                        true
                                    )
                                }
                            >
                                View{" "}
                                {
                                    hiddenRequiredCount
                                }{" "}
                                more required
                                actions.
                            </button>
                        )}

                        {showAllRequiredActions &&
                            unpaidRequiredActions.length >
                            6 && (
                                <button
                                    type="button"
                                    className="text-action-button show-more-inline"
                                    onClick={() =>
                                        setShowAllRequiredActions(
                                            false
                                        )
                                    }
                                >
                                    Show fewer
                                    required actions.
                                </button>
                            )}
                    </>
                )}
            </div>



            <div className="plan-dashboard-section recommended-section">
                <button
                    type="button"
                    className="section-collapse-button recommended-collapse"
                    onClick={() =>
                        setRecommendedExpanded(
                            (current) => !current
                        )
                    }
                >
                    <div className="section-collapse-left">
                        <div>
                            <h2>
                                Recommended Actions
                                <span className="section-count-pill">
                                    {
                                        recommendedActions.length
                                    }
                                </span>
                            </h2>

                            <p className="section-collapse-subtitle">
                                Best next move for
                                this paycheck.
                            </p>
                        </div>
                    </div>

                    <span
                        className={
                            recommendedExpanded
                                ? "collapse-chevron expanded"
                                : "collapse-chevron"
                        }
                    >
                        ▼
                    </span>
                </button>

                {recommendedExpanded && (
                    <>
                        {recommendedActions.length ===
                            0 ? (
                            <p className="empty-state">
                                No emergency fund
                                or extra debt
                                payment recommendation
                                available this pay
                                cycle.
                            </p>
                        ) : (
                            <>
                                <div className="focus-card">
                                    <div className="focus-badge">
                                        Focus Target
                                    </div>

                                    {renderRecommendedAction(visibleRecommendedActions[0], {
                                        isFocusTarget: true
                                    }
                                    )}
                                </div>

                                {visibleRecommendedActions.length >
                                    1 && (
                                        <div className="secondary-recommendations">
                                            {visibleRecommendedActions
                                                .slice(1)
                                                .map((item) =>
                                                    renderRecommendedAction(
                                                        item
                                                    )
                                                )}
                                        </div>
                                    )}

                                {hiddenRecommendedCount >
                                    0 && (
                                        <button
                                            type="button"
                                            className="text-action-button show-more-inline"
                                            onClick={() =>
                                                setShowAllRecommendedActions(
                                                    true
                                                )
                                            }
                                        >
                                            View{" "}
                                            {
                                                hiddenRecommendedCount
                                            }{" "}
                                            more
                                            recommended
                                            actions.
                                        </button>
                                    )}

                                {showAllRecommendedActions &&
                                    recommendedActions.length >
                                    5 && (
                                        <button
                                            type="button"
                                            className="text-action-button show-more-inline"
                                            onClick={() =>
                                                setShowAllRecommendedActions(
                                                    false
                                                )
                                            }
                                        >
                                            Show fewer
                                            recommended
                                            actions.
                                        </button>
                                    )}
                            </>
                        )}
                    </>
                )}
            </div>

            {completedRequiredActions.length > 0 && (
                <div className="plan-dashboard-section completed-section">
                    <button
                        type="button"
                        className="section-collapse-button"
                        onClick={() =>
                            setCompletedExpanded(
                                (current) => !current
                            )
                        }
                    >
                        <div className="section-collapse-left">
                            <h2>
                                Completed This Cycle
                            </h2>

                            <span className="section-count-pill">
                                {
                                    completedRequiredActions.length
                                }
                            </span>
                        </div>

                        <span
                            className={
                                completedExpanded
                                    ? "collapse-chevron expanded"
                                    : "collapse-chevron"
                            }
                        >
                            ▼
                        </span>
                    </button>

                    {completedExpanded && (
                        <div className="required-actions-list">
                            {completedRequiredActions.map(
                                (item, index) =>
                                    renderRequiredAction(
                                        item,
                                        index
                                    )
                            )}
                        </div>
                    )}
                </div>
            )}

            {optionalGoalActions.length > 0 && (
                <div className="plan-dashboard-section">
                    <h2>Optional Goals</h2>

                    <p className="empty-state">
                        These are optional savings
                        contributions after required
                        payments and debt payoff
                        recommendations.
                    </p>

                    {optionalGoalActions.map((item) =>
                        renderRecommendedAction(item)
                    )}
                </div>
            )}
        </section>
    );
}
