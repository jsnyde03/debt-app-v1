import type { Recurrence } from "../types/recurrence";
import type { LivingExpense } from "../types/livingExpense";

export type Expense = {
id: string;
name: string;
amount: number;
dueDate: string;
recurrence: Recurrence;
isPaidThisCycle?: boolean;
};

export type Debt = {
id: string;
name: string;
balance: number;
minimumPayment: number;
apr: number;
dueDate: string;
type: "debt" | "bnpl";
recurrence: Recurrence;
isPaidThisCycle?: boolean;
minimumPaidThisCycle?: boolean;
snowballPaidThisCycle?: boolean;
};

export type Goal = {
id: string;
name: string;
targetAmount: number;
currentAmount: number;
type: "emergency" | "savings";
};

export type AllocationItem = {
label: string;
amount: number;
category:
| "expense"
| "minimum_debt"
| "emergency"
| "snowball"
| "optional_goal"
| "leftover";
targetId?: string;
debtId?: string;
goalId?: string;
};

export type UnfundedRequiredItem = {
label: string;
amount: number;
category: "expense" | "minimum_debt";
debtId?: string;
};

type AllocatePaycheckParams = {
paycheckAmount: number;
currentDate: string;
nextPaycheckDate: string;
expenses: Expense[];
livingExpenses: LivingExpense[];
debts: Debt[];
goals: Goal[];
strategy: "snowball" | "avalanche";
paycheckBuffer?: number;
};

export function allocatePaycheck({
paycheckAmount,
nextPaycheckDate,
expenses,
livingExpenses,
debts,
goals,
strategy,
paycheckBuffer = 50,
}: AllocatePaycheckParams) {
const roundMoney = (amount: number) => Math.round(amount * 100) / 100;

let remaining = roundMoney(paycheckAmount);

const allocations: AllocationItem[] = [];
const unfundedRequiredItems: UnfundedRequiredItem[] = [];

const isDueBeforeNextPaycheck = (dueDate: string) => {
const due = new Date(`${dueDate}T00:00:00`);
const next = new Date(`${nextPaycheckDate}T00:00:00`);

return due < next;
};

const upcomingExpenses = expenses
.filter((expense) => isDueBeforeNextPaycheck(expense.dueDate))
.sort(
(a, b) =>
new Date(a.dueDate).getTime() -
new Date(b.dueDate).getTime()
);

const upcomingMinimums = debts
.filter((debt) => isDueBeforeNextPaycheck(debt.dueDate))
.sort(
(a, b) =>
new Date(a.dueDate).getTime() -
new Date(b.dueDate).getTime()
);

const expenseRequiredTotal = upcomingExpenses.reduce(
(sum, expense) => sum + expense.amount,
0
);

const debtMinimumRequiredTotal = upcomingMinimums.reduce(
(sum, debt) => sum + Math.min(debt.minimumPayment, debt.balance),
0
);

const totalRequired = roundMoney(
expenseRequiredTotal + debtMinimumRequiredTotal
);

const livingExpenseReserve = roundMoney(
	livingExpenses.filter((expense) => expense.enabled).reduce((sum, expense) => sum + expense.amount, 0);
)

const paidExpenseTotal = upcomingExpenses
.filter((expense) => expense.isPaidThisCycle)
.reduce((sum, expense) => sum + expense.amount, 0);

const paidDebtMinimumTotal = upcomingMinimums
.filter((debt) => debt.minimumPaidThisCycle ?? debt.isPaidThisCycle)
.reduce(
(sum, debt) => sum + Math.min(debt.minimumPayment, debt.balance),
0
);

const paidRequiredTotal = roundMoney(
paidExpenseTotal + paidDebtMinimumTotal
);

remaining = roundMoney(Math.max(0, remaining - paidRequiredTotal));

const unpaidExpenses = upcomingExpenses.filter(
(expense) => !expense.isPaidThisCycle
);

const unpaidMinimums = upcomingMinimums.filter(
(debt) => !(debt.minimumPaidThisCycle ?? debt.isPaidThisCycle)
);

const unpaidRequiredTotal = roundMoney(
unpaidExpenses.reduce((sum, expense) => sum + expense.amount, 0) +
unpaidMinimums.reduce(
(sum, debt) => sum + Math.min(debt.minimumPayment, debt.balance),
0
)
);

const shortfall = roundMoney(Math.max(0, unpaidRequiredTotal - remaining));

const paidTowardDebt = (debtId: string) => {
const debt = upcomingMinimums.find((item) => item.id === debtId);

const alreadyPaidMinimum =
debt?.minimumPaidThisCycle ?? debt?.isPaidThisCycle ?? false;

const paidMinimumAmount =
alreadyPaidMinimum && debt
? Math.min(debt.minimumPayment, debt.balance)
: 0;

const allocatedAmount = allocations
.filter(
(item) =>
item.debtId === debtId &&
(item.category === "minimum_debt" ||
item.category === "snowball")
)
.reduce((sum, item) => sum + item.amount, 0);

return roundMoney(paidMinimumAmount + allocatedAmount);
};

for (const expense of unpaidExpenses) {
const coveredAmount = roundMoney(Math.min(expense.amount, remaining));
const unfundedAmount = roundMoney(expense.amount - coveredAmount);

if (coveredAmount > 0) {
allocations.push({
label:
coveredAmount === expense.amount
? `Pay ${expense.name}`
: `Pay ${expense.name} (partial)`,
amount: coveredAmount,
category: "expense",
targetId: expense.id,
});

remaining = roundMoney(remaining - coveredAmount);
}

if (unfundedAmount > 0) {
unfundedRequiredItems.push({
label:
coveredAmount > 0
? `Finish ${expense.name}`
: `Pay ${expense.name}`,
amount: unfundedAmount,
category: "expense",
});
}
}

for (const debt of unpaidMinimums) {
const remainingDebtBalance = roundMoney(
Math.max(0, debt.balance - paidTowardDebt(debt.id))
);

const requiredMinimum = roundMoney(
Math.min(debt.minimumPayment, remainingDebtBalance)
);

const coveredAmount = roundMoney(Math.min(requiredMinimum, remaining));
const unfundedAmount = roundMoney(requiredMinimum - coveredAmount);

if (coveredAmount > 0) {
allocations.push({
label:
coveredAmount === requiredMinimum
? `Pay minimum on ${debt.name}`
: `Pay minimum on ${debt.name} (partial)`,
amount: coveredAmount,
category: "minimum_debt",
targetId: debt.id,
debtId: debt.id,
});

remaining = roundMoney(remaining - coveredAmount);
}

if (unfundedAmount > 0) {
unfundedRequiredItems.push({
label:
coveredAmount > 0
? `Pay remaining minimum on ${debt.name}`
: `Pay minimum on ${debt.name}`,
amount: unfundedAmount,
category: "minimum_debt",
debtId: debt.id,
});
}
}

if (shortfall === 0 && remaining > 0 && paycheckBuffer > 0) {
const amount = roundMoney(Math.min(paycheckBuffer, remaining));

allocations.push({
label: "Keep cash buffer",
amount,
category: "leftover",
});

remaining = roundMoney(remaining - amount);
}

const emergencyGoal = goals.find((goal) => goal.type === "emergency");

if (
emergencyGoal &&
emergencyGoal.currentAmount < emergencyGoal.targetAmount &&
remaining > 0
) {
const emergencyNeeded = roundMoney(
emergencyGoal.targetAmount - emergencyGoal.currentAmount
);

const amount = roundMoney(Math.min(emergencyNeeded, remaining));

allocations.push({
label: `Add to ${emergencyGoal.name}`,
amount,
category: "emergency",
targetId: emergencyGoal.id,
goalId: emergencyGoal.id,
});

remaining = roundMoney(remaining - amount);
}

const sortedSnowballDebts = debts
.filter((debt) => debt.balance - paidTowardDebt(debt.id) > 0)
.sort((a, b) => {
if (strategy === "avalanche") {
return b.apr - a.apr;
}

return (
a.balance -
paidTowardDebt(a.id) -
(b.balance - paidTowardDebt(b.id))
);
});

for (const debt of sortedSnowballDebts) {
if (remaining <= 0) break;

const remainingDebtBalance = roundMoney(
debt.balance - paidTowardDebt(debt.id)
);

const amount = roundMoney(Math.min(remaining, remainingDebtBalance));

if (amount <= 0) continue;

allocations.push({
label: `Extra payment to ${debt.name}`,
amount,
category: "snowball",
targetId: debt.id,
debtId: debt.id,
});

remaining = roundMoney(remaining - amount);
}

const savingsGoals = goals.filter(
(goal) =>
goal.type === "savings" && goal.currentAmount < goal.targetAmount
);

for (const goal of savingsGoals) {
if (remaining <= 0) break;

const needed = roundMoney(goal.targetAmount - goal.currentAmount);
const amount = roundMoney(Math.min(remaining, needed));

if (amount <= 0) continue;

allocations.push({
label: `Optional contribution to ${goal.name}`,
amount,
category: "optional_goal",
targetId: goal.id,
goalId: goal.id,
});

remaining = roundMoney(remaining - amount);
}

if (remaining > 0) {
allocations.push({
label: "Leftover cash",
amount: roundMoney(remaining),
category: "leftover",
});
}

return {
paycheckAmount,
allocations,
unfundedRequiredItems,
remaining: roundMoney(remaining),
totalRequired,
shortfall,
};
}
