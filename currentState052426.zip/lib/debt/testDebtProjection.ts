import { projectDebtPayoff } from "./projectDebtPayoff";

function assertEqual<T>(
actual: T,
expected: T,
label: string
) {
if (actual !== expected) {
throw new Error(
`${label} failed. Expected ${String(expected)}, received ${String(actual)}`
);
}
}

function assertGreaterThan(
actual: number,
expected: number,
label: string
) {
if (!(actual > expected)) {
throw new Error(
`${label} failed. Expected greater than ${expected}, received ${actual}`
);
}
}

function runDebtProjectionTests() {

// -------------------------
// Snowball prioritization
// -------------------------

const snowballProjection = projectDebtPayoff({
debts: [
{
id: "small",
name: "Small Debt",
balance: 300,
minimumPayment: 50,
apr: 5,
dueDate: "2026-05-01",
type: "debt",
recurrence: "monthly",
isPaidThisCycle: false,
},
{
id: "large",
name: "Large Debt",
balance: 5000,
minimumPayment: 100,
apr: 29,
dueDate: "2026-05-01",
type: "debt",
recurrence: "monthly",
isPaidThisCycle: false,
},
],
monthlyExtraPayment: 300,
strategy: "snowball",
startDate: "2026-05-01",
});

assertEqual(
snowballProjection.payoffOrder[0],
"Small Debt",
"snowball payoff order"
);

// -------------------------
// Avalanche prioritization
// -------------------------

const avalancheProjection = projectDebtPayoff({
debts: [
{
id: "lowapr",
name: "Low APR",
balance: 5000,
minimumPayment: 50,
apr: 5,
dueDate: "2026-05-01",
type: "debt",
recurrence: "monthly",
isPaidThisCycle: false,
},
{
id: "highapr",
name: "High APR",
balance: 300,
minimumPayment: 100,
apr: 29,
dueDate: "2026-05-01",
type: "debt",
recurrence: "monthly",
isPaidThisCycle: false,
},
],
monthlyExtraPayment: 300,
strategy: "avalanche",
startDate: "2026-05-01",
});

assertEqual(
avalancheProjection.payoffOrder[0],
"High APR",
"avalanche payoff order"
);

// -------------------------
// Interest accrual validation
// -------------------------

assertGreaterThan(
avalancheProjection.totalInterestPaid,
0,
"interest accrual"
);

// -------------------------
// Debt-free projection exists
// -------------------------

assertGreaterThan(
avalancheProjection.monthsToDebtFree,
0,
"months to debt free"
);

// -------------------------
// Cannot amortize detection
// -------------------------

const impossibleProjection = projectDebtPayoff({
debts: [
{
id: "bad",
name: "Impossible Debt",
balance: 10000,
minimumPayment: 10,
apr: 35,
dueDate: "2026-05-01",
type: "debt",
recurrence: "monthly",
isPaidThisCycle: false,
},
],
monthlyExtraPayment: 0,
strategy: "snowball",
startDate: "2026-05-01",
});

assertEqual(
impossibleProjection.estimatedDebtFreeDate,
"Unable to estimate",
"negative amortization detection"
);

// -------------------------
// Overpayment prevention
// -------------------------

const overpaymentProjection = projectDebtPayoff({
debts: [
{
id: "tiny",
name: "Tiny Debt",
balance: 50,
minimumPayment: 100,
apr: 0,
dueDate: "2026-05-01",
type: "debt",
recurrence: "monthly",
isPaidThisCycle: false,
},
],
monthlyExtraPayment: 1000,
strategy: "snowball",
startDate: "2026-05-01",
});

assertEqual(
overpaymentProjection.monthsToDebtFree,
1,
"overpayment prevention payoff timing"
);

console.log("✅ Debt projection regression tests passed.");
}

runDebtProjectionTests();
