export type SmartInsightSeverity = "good" | "warning" | "risk";

export type SmartInsight = {
    title: string;
    message: string;
    severity: SmartInsightSeverity;
};

type BuildSmartInsightParams = {
    safeExtraPayment: number;
    safeCash: number;
    requiredTotal: number;
    snowballDebtFreeDate: string;
    avalancheDebtFreeDate: string;
    snowballInterest: number;
    avalancheInterest: number;
};

export function buildSmartInsights({ safeExtraPayment, safeCash, requiredTotal, snowballDebtFreeDate, avalancheDebtFreeDate, snowballInterest, avalancheInterest}: BuildSmartInsightParams): SmartInsight[] {
    const insights: SmartInsight[] = [];

    if (safeExtraPayment > 0) {
        insights.push({
            title: "Safe Extra Payment",
            message: `You can safely apply ${formatInsightCurrency(safeExtraPayment)} toward debt this cycle without touching required payments or reserves.`,
            severity: "good",
        });
    } else {
        insights.push({
            title: "No Safe Extra Payment",
            message: "This cycle does not currently show extra cash available for additional debt payoff.",
            severity: "warning",
        });
    }

    if (safeCash < 0) {
        insights.push({
            title: "Cash Flow Risk",
            message: "This plan projects a cash shortfall.  Focus on required payments and minimums before extra payoff.",
            severity: "risk",
        });
    } else if (safeCash < 200) {
        insights.push({
            title: "Cash Flow Pressure",
            message: "Safe cash is projected below $200.  Consider keeping extra payoff conservative this cycle.",
            severity: "warning",
        });
    } else {
        insights.push({
            title: "Buffer Looks Stable",
            message: "Your projected safe cash appears stable after required payments and reserves.",
            severity: "good",
        });
    }

    if (avalancheInterest < snowballInterest) {
        insights.push({
            title: "Debt Efficiency Guidance",
            message: `Avalanche is projected to reduce interest compared with snowball while targeting higher APR first`,
            severity: "good",
        });
    } else if (snowballDebtFreeDate !== avalancheDebtFreeDate) {
        insights.push({
            title: "Debt Strategy Guidance",
            message: "Snowball and avalanche produce different payoff timelines.  Compare before choosing your focus.",
            severity: "warning",
        });
    }

    if (requiredTotal > safeCash && safeCash < 200) {
        insights.push({
            title: "Stabilization Suggestion",
            message: "A minimum-only approach may be safer until cash flow pressure improves.",
            severity: "warning",
        });
    }

    return insights;
}

function formatInsightCurrency(amount: number) {
    return new Intl.NumberFormat("en-US", {
        style: "currency",
        currency: "USD",
    }).format(amount);
}