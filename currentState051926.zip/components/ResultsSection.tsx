import { useState } from "react";
import type { allocatePaycheck } from "@/lib/engine/allocatePaycheck";
import type { Debt, RequiredExpense } from "@/lib/storage/debtPlannerStorage";
import { formatCurrency } from "@/lib/utils/formatCurrency";

type AllocationResult = ReturnType<typeof allocatePaycheck>;

type Goal = {
    id: string;
    name: string;
    targetAmount: number;
    currentAmount: number;
    type: "emergency" | "savings";
};

type RecommendedCategory = "emergency" | "snowball" | "optional_goal";

type CompletedRecommendedAction = {
    targetId: string;
    label: string;
    category: RecommendedCategory;
    recommendedAmount: number;
    actualAmount: number;
};

type ResultsSectionProps = {
    result: AllocationResult | null;
    requiredExpenses: RequiredExpense[];
    debts: Debt[];
    goals: Goal[];
    completedRecommendedActions: CompletedRecommendedAction[];
    currentDate: string;
    onMarkExpensePaid: (id: string) => void;
    onMarkDebtMinimumPaid: (id: string) => void;
    onMarkDebtSnowballPaid: (id: string) => void;
    onMarkRecommendedAction: (
        targetId: string,
        label: string,
        category: RecommendedCategory,
        recommendedAmount: number,
        actualAmount: number
    ) => void;
};

function isOverdue(dueDate: string, currentDate: string) {
    return new Date(`${dueDate}T00:00:00`) < new Date(`${currentDate}T00:00:00`);
}

function isRecommendedCategory(category: string): category is RecommendedCategory {
    return (
        category === "emergency" ||
        category === "snowball" ||
        category === "optional_goal"
    );
}

export function ResultsSection({
    result,
    requiredExpenses,
    debts,
    goals,
    completedRecommendedActions,
    currentDate,
    onMarkExpensePaid,
    onMarkDebtMinimumPaid,
    onMarkRecommendedAction,
}: ResultsSectionProps) {
    
    const [editingRecommendedKey, setEditingRecommendedKey] = useState<string | null>(null);
  const [showAllRequiredActions, setShowAllRequiredActions] = useState(false);
    const [editedRecommendedAmounts, setEditedRecommendedAmounts] = useState<
        Record<string, string>
    >({});

    const [recommendedAmountErrors, setRecommendedAmountErrors] = useState<
        Record<string, string>
    >({});

    if (!result) {
        return null;
    }

    const requiredActions = result.allocations.filter(
        (item) => item.category === "expense" || item.category === "minimum_debt"
    );
   
    const recommendedActions = result.allocations.filter(
        (item) => item.category === "emergency" || item.category === "snowball"
    );

    const optionalGoalActions = result.allocations.filter(
        (item) => item.category === "optional_goal"
    );

    const bufferActions = result.allocations.filter(
        (item) => item.category === "leftover" && item.label === "Keep cash buffer"
    );

    const bufferTotal = bufferActions.reduce((sum, item) => sum + item.amount, 0);

    const requiredTotal = requiredActions.reduce((sum, item) => sum + item.amount, 0);

    const completedRecommendedTotal = completedRecommendedActions.reduce(
        (sum, action) => sum + action.actualAmount,
        0
    );

    const allSuggestedActions = [...recommendedActions, ...optionalGoalActions];

    const remainingRecommendedTotal = allSuggestedActions.reduce((sum, item) => {
        const completedForItem = completedRecommendedActions
            .filter(
                (action) =>
                    action.targetId === item.targetId &&
                    action.label === item.label &&
                    action.category === item.category
            )
            .reduce((completedSum, action) => completedSum + action.actualAmount, 0);

        return sum + Math.max(0, item.amount - completedForItem);
    }, 0);

    const flexibleCashAvailable =
        result.paycheckAmount -
        requiredTotal -
        bufferTotal -
        completedRecommendedTotal;

    const hasOverdueItems = requiredActions.some((item) => {
        const expense = requiredExpenses.find((expense) => expense.id === item.targetId);
        const debt = debts.find((debt) => debt.id === item.targetId);
        const dueDate = expense?.dueDate ?? debt?.dueDate;

        return dueDate ? isOverdue(dueDate, currentDate) : false;
    });
   

    const visibleRequiredActions = showAllRequiredActions
        ? requiredActions
        : requiredActions.slice(0, 6);

    const hiddenRequiredCount = Math.max(0, requiredActions.length - visibleRequiredActions.length);
   

    function getRecommendedKey(item: {
        category: string;
        targetId?: string;
        label: string;
    }) {
        return `${item.category}-${item.targetId ?? "none"}-${item.label}`;
    }

    function getCompletedAction(item: {
        category: string;
        targetId?: string;
        label: string;
    }) {
        return completedRecommendedActions.find(
            (action) =>
                action.targetId === item.targetId &&
                action.label === item.label &&
                action.category === item.category
        );
    }

    function getActualAmount(item: {
        amount: number;
        category: string;
        targetId?: string;
        label: string;
    }) {
        const key = getRecommendedKey(item);
        const editedAmount = editedRecommendedAmounts[key];

        if (editedAmount === undefined || editedAmount === "") {
            return item.amount;
        }

        return Number(editedAmount);
    }

    function getRemainingDebtBalance(targetId?: string) {
        if (!targetId) {
            return null;
        }

        const debt = debts.find((item) => item.id === targetId);

        if (!debt) {
            return null;
        }

        const completedForDebt = completedRecommendedActions
            .filter(
                (action) =>
                    action.category === "snowball" && action.targetId === targetId
            )
            .reduce((sum, action) => sum + action.actualAmount, 0);

        return Math.max(0, debt.balance - completedForDebt);
    }

    function getRemainingGoalAmount(targetId?: string) {
        if (!targetId) {
            return null;
        }

        const goal = goals.find((item) => item.id === targetId);

        if (!goal) {
            return null;
        }

        const completedForGoal = completedRecommendedActions
            .filter(
                (action) =>
                    (action.category === "emergency" ||
                        action.category === "optional_goal") &&
                    action.targetId === targetId
            )
            .reduce((sum, action) => sum + action.actualAmount, 0);

        return Math.max(0, goal.targetAmount - goal.currentAmount - completedForGoal);
    }

    function renderRecommendedAction(item: AllocationResult["allocations"][number]) {
        const key = getRecommendedKey(item);
        const completed = getCompletedAction(item);
        const actualAmount = getActualAmount(item);
        const displayAmount = completed?.actualAmount ?? actualAmount;

        return (
            <div
                key={key}
                className={
                    completed
                        ? "saved-item recommended-card completed-action"
                        : "saved-item recommended-card"
                }
            >
                <div className="saved-item-left">
                    <div className="saved-title">{item.label}</div>

                    <div className="saved-meta">
                        Suggested for this cycle
                    </div>

                    {completed && (
                        <div className="status-chip completed">
                            Completed
                        </div>
                    )}

                    {recommendedAmountErrors[key] && (
                        <p className="validation-error">
                            {recommendedAmountErrors[key]}
                        </p>
                    )}
                </div>

                <div className="saved-item-right">
                    <strong className="saved-amount">
                        {formatCurrency(displayAmount)}
                    </strong>

                    <button
                        type="button"
                        className={
                            completed ? "action-pill completed" : "action-pill"
                        }
                        onClick={() => {
                            const category = item.category;

                            if (!isRecommendedCategory(category)) {
                                return;
                            }

                            if (!item.targetId) {
                                return;
                            }

                            if (completed) {
                                setRecommendedAmountErrors((current) => ({
                                    ...current,
                                    [key]: "",
                                }));

                                onMarkRecommendedAction(
                                    item.targetId,
                                    item.label,
                                    category,
                                    item.amount,
                                    completed.actualAmount
                                );

                                setEditingRecommendedKey(null);
                                return;
                            }

                            const amountToApply = getActualAmount(item);

                            if (amountToApply < 0) {
                                setRecommendedAmountErrors((current) => ({
                                    ...current,
                                    [key]: "Amount cannot be negative.",
                                }));
                                return;
                            }

                            if (amountToApply > item.amount) {
                                setRecommendedAmountErrors((current) => ({
                                    ...current,
                                    [key]: `You're paying more than recommended. Recommended: ${formatCurrency(
                                        item.amount
                                    )}.`,
                                }));
                                return;
                            }

                            if (amountToApply > flexibleCashAvailable) {
                                setRecommendedAmountErrors((current) => ({
                                    ...current,
                                    [key]: "Amount exceeds flexible cash.",
                                }));
                                return;
                            }

                            if (category === "snowball") {
                                const remainingDebtBalance = getRemainingDebtBalance(
                                    item.targetId
                                );

                                if (
                                    remainingDebtBalance !== null &&
                                    amountToApply > remainingDebtBalance
                                ) {
                                    setRecommendedAmountErrors((current) => ({
                                        ...current,
                                        [key]: `Amount exceeds remaining debt balance of ${formatCurrency(
                                            remainingDebtBalance
                                        )}.`,
                                    }));
                                    return;
                                }
                            }

                            if (
                                category === "emergency" ||
                                category === "optional_goal"
                            ) {
                                const remainingGoalAmount = getRemainingGoalAmount(
                                    item.targetId
                                );

                                if (
                                    remainingGoalAmount !== null &&
                                    amountToApply > remainingGoalAmount
                                ) {
                                    setRecommendedAmountErrors((current) => ({
                                        ...current,
                                        [key]: `Amount exceeds remaining goal amount of ${formatCurrency(
                                            remainingGoalAmount
                                        )}.`,
                                    }));
                                    return;
                                }
                            }

                            setRecommendedAmountErrors((current) => ({
                                ...current,
                                [key]: "",
                            }));

                            onMarkRecommendedAction(
                                item.targetId,
                                item.label,
                                category,
                                item.amount,
                                amountToApply
                            );

                            setEditingRecommendedKey(null);
                        }}
                    >
                        {completed
                            ? "Undo"
                            : item.category === "emergency" ||
                                item.category === "optional_goal"
                                ? "Mark Saved"
                                : "Mark Paid"}
                    </button>
                </div>
            </div>
        );
    }

    return (
        <section className="card plan-dashboard">
            <div className="plan-dashboard-header">
                <div>
                    <h2>This Paycheck</h2>
                    <p
                        className={
                            hasOverdueItems || result.shortfall > 0
                                ? "status-warning"
                                : "status-good"
                        }
                    >
                        {hasOverdueItems
                            ? "You have overdue payments requiring attention."
                            : result.shortfall > 0
                                ? `You're short ${formatCurrency(result.shortfall)} this cycle.`
                                : "You're on track this cycle."}
                    </p>
                </div>
            </div>

            <div className="plan-snapshot-grid">
                <div className="summary-card">
                    <span>Required</span>
                    <strong>{formatCurrency(requiredTotal)}</strong>
                </div>

                <div className="summary-card">
                    <span>Recommended</span>
                    <strong>{formatCurrency(remainingRecommendedTotal)}</strong>
                </div>

                <div className="summary-card">
                    <span>Flexible Cash</span>
                    <strong>{formatCurrency(flexibleCashAvailable)}</strong>
                </div>

                <div className="summary-card">
                    <span>Status</span>
                    <strong>
                        {hasOverdueItems
                            ? "Overdue"
                            : result.shortfall > 0
                                ? "Short"
                                : "On Track"}
                    </strong>
                </div>
            </div>

            <div className="plan-dashboard-section">
                <h2>Required Actions</h2>

                {requiredActions.length === 0 ? (
                    <p className="empty-state">
                        No required expenses or debt minimums due this pay cycle.
                    </p>
                ) : (
                    visibleRequiredActions.map((item, index) => {
                        const expense =
                            item.category === "expense"
                                ? requiredExpenses.find(
                                    (expenseItem) =>
                                        expenseItem.id === item.targetId
                                )
                                : undefined;

                        const debt =
                            item.category === "minimum_debt"
                                ? debts.find(
                                    (debtItem) =>
                                        debtItem.id ===
                                        (item.debtId ?? item.targetId)
                                )
                                : undefined;

                        const isPaid =
                            item.category === "expense"
                                ? expense?.isPaidThisCycle ?? false
                                : debt?.minimumPaidThisCycle ??
                                debt?.isPaidThisCycle ??
                                false;

                        const dueDate = expense?.dueDate ?? debt?.dueDate;
                        const overdue = dueDate
                            ? isOverdue(dueDate, currentDate)
                            : false;

                        return (
                            <div
                                key={`${item.category}-${item.targetId ?? index}`}
                                className={`saved-item ${isPaid ? "completed-item" : ""
                                    } ${overdue ? "overdue-item" : ""}`}
                            >
                                <div className="saved-item-left">
                                    <div className="saved-title">
                                        {item.label}
                                    </div>

                                    {overdue && (
                                        <div className="status-chip overdue">
                                            Overdue
                                        </div>
                                    )}

                                    {isPaid && (
                                        <div className="status-chip completed">
                                            Paid
                                        </div>
                                    )}

                                    <div className="saved-meta">
                                        {dueDate
                                            ? `Due ${dueDate}`
                                            : "Required Payment"}
                                    </div>
                                </div>

                                <div className="saved-item-right">
                                    <strong className="saved-amount">
                                        {formatCurrency(item.amount)}
                                    </strong>

                                    <button
                                        type="button"
                                        className={
                                            isPaid
                                                ? "action-pill completed"
                                                : "action-pill"
                                        }
                                        onClick={() => {
                                            if (item.category === "expense") {
                                                if (item.targetId) {
                                                    onMarkExpensePaid(item.targetId);
                                                }

                                                return;
                                            }

                                            if (item.category === "minimum_debt") {
                                                const debtId =
                                                    item.debtId ?? item.targetId;

                                                if (debtId) {
                                                    onMarkDebtMinimumPaid(debtId);
                                                }
                                            }
                                        }}
                                    >
                                        {isPaid ? "Undo" : "Mark Paid"}
                                    </button>
                                </div>
                            </div>
                        );
                    })

                   
                )}

                 {hiddenRequiredCount > 0 && (
                        <button
                            type="button"
                            className="text-action-button show-more-inline"
                            onClick={() => setShowAllRequiredActions(true)}
                        >
                            View {hiddenRequiredCount} more required actions.   
                        </button>
                    )}

                    {showAllRequiredActions && requiredActions.length > 6 && (
                        <button
                            type="button"
                            className="text-action-button show-more-inline"
                            onClick={() => setShowAllRequiredActions(false)}
                        >
                            Show fewer required actions.
                        </button>
                    )} 
            </div>

            <div className="plan-dashboard-section recommended-section">
                <div className="section-heading-row">
                    <div>
                        <h2>Recommended Actions</h2>
                        <p className="empty-state">
                            Best next move for this paycheck.
                        </p>
                    </div>
                </div>

                {recommendedActions.length === 0 ? (
                    <p className="empty-state">
                        No emergency fund or extra debt payment recommendation
                        available this pay cycle.
                    </p>
                ) : (
                    <>
                        <div className="focus-card">
                            <div className="focus-badge">Focus Target</div>

                            {renderRecommendedAction(recommendedActions[0])}
                        </div>

                        {recommendedActions.length > 1 && (
                            <div className="secondary-recommendations">
                                {recommendedActions
                                    .slice(1, 4)
                                    .map((item) => renderRecommendedAction(item))}
                            </div>
                        )}
                    </>
                )}
            </div>

            {optionalGoalActions.length > 0 && (
                <div className="plan-dashboard-section">
                    <h2>Optional Goals</h2>
                    <p className="empty-state">
                        These are optional savings contributions after required
                        payments and debt payoff recommendations.
                    </p>

                    {optionalGoalActions.map((item) =>
                        renderRecommendedAction(item)
                    )}
                </div>
            )}
        </section>
    );
}
