"use client";

import { useEffect, useState } from "react";
import { allocatePaycheck } from "@/lib/engine/allocatePaycheck";
import {
    getNextPaycheckDate,
    type PayCycle,
} from "@/lib/payCycle/getNextPaycheckDate";
import type { Recurrence } from "@/lib/types/recurrence";
import "./page.css";

import { ResultsSection } from "@/components/ResultsSection";
import { GoalsSection } from "@/components/GoalsSection";
import { RequiredExpensesSection } from "@/components/RequiredExpensesSection";
import { DebtsSection } from "@/components/DebtsSection";
import { PaycheckSection } from "@/components/PaycheckSection";
import { SnowballSection } from "@/components/SnowballSection";
import {
    rolloverDebts,
    rolloverRequiredExpenses,
} from "@/lib/recurrence/rolloverPayCycle";
import type { Debt, RequiredExpense } from "@/lib/storage/debtPlannerStorage";

type Goal = {
    id: string;
    name: string;
    targetAmount: number;
    currentAmount: number;
    type: "emergency" | "savings";
};

type CompletedRecommendedAction = {
    targetId: string;
    label: string;
    category: "emergency" | "snowball";
    recommendedAmount: number;
    actualAmount: number;
};

function getCurrentDate() {
    const today = new Date();

    return new Date(today.getFullYear(), today.getMonth(), today.getDate())
        .toISOString()
        .slice(0, 10);
}

function formatRecurrence(recurrence: Recurrence) {
    switch (recurrence) {
        case "one-time":
            return "One-time";
        case "weekly":
            return "Weekly";
        case "biweekly":
            return "Every 2 weeks";
        case "per-paycheck":
            return "Every paycheck";
        case "monthly":
        default:
            return "Monthly";
    }
}

function loadStoredState<T>(key: string, fallback: T): T {
    if (typeof window === "undefined") return fallback;

    const stored = window.localStorage.getItem(key);
    if(!stored) return fallback;

    try {
        return JSON.parse(stored) as T;
    } catch {
        return fallback;
    }
}

export default function Home() {
    const [amount, setAmount] = useState("");
    const [result, setResult] =  useState<ReturnType<typeof allocatePaycheck> | null>(null);

    const [payCycle, setPayCycle] = useState<PayCycle>("biweekly");
    const [semiMonthlyFirstDay, setSemiMonthlyFirstDay] = useState("1");
    const [semiMonthlySecondDay, setSemiMonthlySecondDay] = useState("15");
    const [monthlyPayDay, setMonthlyPayDay] = useState("1");

    const [requiredExpenses, setRequiredExpenses] = useState<RequiredExpense[]>(() => loadStoredState("debtPlanner.requiredExpenses", []));
    const [expenseName, setExpenseName] = useState("");
    const [expenseAmount, setExpenseAmount] = useState("");
    const [expenseDueDate, setExpenseDueDate] = useState("");
    const [expenseRecurrence, setExpenseRecurrence] = useState<Recurrence>("monthly");
    const [expenseType, setExpenseType] = useState<"fixed" | "variable">("fixed");

    const [debts, setDebts] = useState<Debt[]>(() => loadStoredState("debtPlanner.debts", []));
    const [debtName, setDebtName] = useState("");
    const [debtBalance, setDebtBalance] = useState("");
    const [debtMinimumPayment, setDebtMinimumPayment] = useState("");
    const [debtDueDate, setDebtDueDate] = useState("");
    const [debtApr, setDebtApr] = useState("");
    const [debtType, setDebtType] = useState<"debt" | "bnpl">("debt");
    const [debtRecurrence, setDebtRecurrence] = useState<Recurrence>("monthly");

    const [goals, setGoals] = useState<Goal[]>(() => loadStoredState("debtPlanner.goals", []))
    const [goalName, setGoalName] = useState("Starter Emergency Fund");
    const [goalTargetAmount, setGoalTargetAmount] = useState("1000");
    const [goalCurrentAmount, setGoalCurrentAmount] = useState("");
    const [goalType, setGoalType] = useState<"emergency" | "savings">("emergency");

    const [completedRecommendedActions, setCompletedRecommendedActions] = useState<CompletedRecommendedAction[]>([]);

    const [activeTab, setActiveTab] = useState<"plan" | "snowball" | "expenses" | "debts" | "goals">("plan");

    const currentDate = getCurrentDate();
    const [debtErrors, setDebtErrors] = useState<{name?: string; balance?: string; minimumPayment?: string; dueDate?: string; apr?: string;}>({});

    useEffect(() => {
        localStorage.setItem("debtPlanner.requiredExpenses", JSON.stringify(requiredExpenses));
    }, [requiredExpenses]); 

    useEffect(() => {
        localStorage.setItem("debtPlanner.debts", JSON.stringify(debts));
    }, [debts]); 

    useEffect(() => {
        localStorage.setItem("debtPlanner.goals", JSON.stringify(goals));
    }, [goals]); 

    function hasValidPayCycleInputs() {
        if (payCycle === "semimonthly") {
            const first = Number(semiMonthlyFirstDay);
            const second = Number(semiMonthlySecondDay);

            return (
                first >= 1 &&
                first <= 31 &&
                second >= 1 &&
                second <= 31 &&
                first !== second
            );
        }

        if (payCycle === "monthly") {
            const day = Number(monthlyPayDay);
            return day >= 1 && day <= 31;
        }

        return true;
    }

    const nextPaycheckDate = hasValidPayCycleInputs()
        ? getNextPaycheckDate({
            payCycle,
            currentDate,
            semiMonthlyFirstDay: Number(semiMonthlyFirstDay),
            semiMonthlySecondDay: Number(semiMonthlySecondDay),
            monthlyPayDay: Number(monthlyPayDay),
        })
        : "";

    const debtsDueBeforeNextPaycheck = debts.filter((debt) => {
        if (!nextPaycheckDate) return false;

        const due = new Date(`${debt.dueDate}T00:00:00`);

        return (
            due >= new Date(`${currentDate}T00:00:00`) &&
            due < new Date(`${nextPaycheckDate}T00:00:00`)
        );
    });

    const debtsDueAfterNextPaycheck = debts.filter((debt) => {
        if (!nextPaycheckDate) return false;

        const due = new Date(`${debt.dueDate}T00:00:00`);
        return due >= new Date(`${nextPaycheckDate}T00:00:00`);
    });

    useEffect(() => {
        const value = Number(amount);

        if (!value || value <= 0 || !nextPaycheckDate) {
            setResult(null);
            return;
        }

        const calculation = allocatePaycheck({
            paycheckAmount: value,
            currentDate,
            nextPaycheckDate,
            expenses: requiredExpenses,
            debts,
            goals,
            paycheckBuffer: 50,
        });

        setResult(calculation);
    }, [amount, requiredExpenses, debts, goals, currentDate, nextPaycheckDate]);

    function handleCalculate() {
        const value = Number(amount);

        if (!value || value <= 0 || !nextPaycheckDate) {
            setResult(null);
            return;
        }

        const calculation = allocatePaycheck({
            paycheckAmount: value,
            currentDate,
            nextPaycheckDate,
            expenses: requiredExpenses,
            debts,
            goals,
            paycheckBuffer: 50,
        });

        setResult(calculation);
    }

    function handleAddExpense() {
        const parsedAmount = Number(expenseAmount);

       
        if (!expenseName || !parsedAmount || parsedAmount <= 0 || !expenseDueDate) {
            return;
        }

        setRequiredExpenses((current) => [
            ...current,
            {
                id: crypto.randomUUID(),
                name: expenseName,
                amount: parsedAmount,
                dueDate: expenseDueDate,
                recurrence: expenseRecurrence,
                expenseType,
                isPaidThisCycle: false,
            },
        ]);

        setExpenseName("");
        setExpenseAmount("");
        setExpenseDueDate("");
        setExpenseRecurrence("monthly");
        setExpenseType("fixed");
    }

    function handleUpdateExpense(
        id: string,
        updates: Partial<Pick<RequiredExpense, "amount" | "dueDate">>
    ) {
        setRequiredExpenses((current) =>
            current.map((expense) =>
                expense.id === id ? { ...expense, ...updates } : expense
            )
        );
    }

    function handleAddDebt() {
        const balance = Number(debtBalance);
        const minimumPayment = Number(debtMinimumPayment);
        const apr = Number(debtApr || 0);

        const nextErrors: typeof debtErrors = {};
        const trimmedName = debtName.trim();

        if (!balance || balance <= 0) {
            nextErrors.balance = "Balance must be greater than 0.";
        }

        if (!minimumPayment || minimumPayment <= 0) {
            nextErrors.balance = "Minimum payment must be greater than 0.";
        }

        if (minimumPayment > balance) {
            nextErrors.minimumPayment = "Minimum payment must not exceed balance.";
        }

        if (!debtDueDate) {
            nextErrors.dueDate = "Due date is required.";
        }

        if (apr < 0 || apr > 100) {
            nextErrors.apr = "APR must be between 0 and 100.";
        }

        if (Object.keys(nextErrors).length > 0) {
            setDebtErrors(nextErrors);
            return;
        }

        setDebtErrors({});

        setDebts((current) => [
            ...current,
            {
                id: crypto.randomUUID(),
                name: trimmedName,
                balance,
                minimumPayment,
                dueDate: debtDueDate,
                apr,
                type: debtType,
                recurrence: debtRecurrence,
                minimumPaidThisCycle: false,
                snowballPaidThisCycle: false,
            },
        ]);

        setDebtName("");
        setDebtBalance("");
        setDebtMinimumPayment("");
        setDebtDueDate("");
        setDebtApr("");
        setDebtType("debt");
        setDebtRecurrence("monthly");
    }

    function handleUpdateDebt(
        id: string,
        updates: Partial<
            Pick<Debt, "balance" | "minimumPayment" | "dueDate" | "apr">
        >
    ) {
        setDebts((current) =>
            current.map((debt) => (debt.id === id ? { ...debt, ...updates } : debt))
        );
    }

    function handleAddGoal() {
        const targetAmount = Number(goalTargetAmount);
        const currentAmount = Number(goalCurrentAmount || 0);

        if (
            !goalName ||
            !targetAmount ||
            targetAmount <= 0 ||
            currentAmount < 0 ||
            currentAmount > targetAmount
        ) {
            return;
        }

        setGoals((current) => [
            ...current,
            {
                id: crypto.randomUUID(),
                name: goalName,
                targetAmount,
                currentAmount,
                type: goalType,
            },
        ]);

        setGoalName("Starter Emergency Fund");
        setGoalTargetAmount("1000");
        setGoalCurrentAmount("");
        setGoalType("emergency");
    }

    function handleUpdateGoal(
        id: string,
        updates: Partial<Pick<Goal, "targetAmount" | "currentAmount">>
    ) {
        setGoals((current) =>
            current.map((goal) => (goal.id === id ? { ...goal, ...updates } : goal))
        );
    }

    function handleRemoveExpense(id: string) {
        setRequiredExpenses((current) =>
            current.filter((expense) => expense.id !== id)
        );
    }

    function handleRemoveDebt(id: string) {
        setDebts((current) => current.filter((debt) => debt.id !== id));
    }

    function handleRemoveGoal(id: string) {
        setGoals((current) => current.filter((goal) => goal.id !== id));
    }

    function handleMarkExpensePaid(id: string) {
        setRequiredExpenses((current) =>
            current.map((expense) =>
                expense.id === id
                    ? { ...expense, isPaidThisCycle: !expense.isPaidThisCycle }
                    : expense
            )
        );
    }

    function handleMarkDebtMinimumPaid(id: string) {
        setDebts((current) =>
            current.map((debt) => {
                const currentlyPaid =
                    debt.minimumPaidThisCycle ?? debt.isPaidThisCycle ?? false;

                return debt.id === id
                    ? {
                        ...debt,
                        minimumPaidThisCycle: !currentlyPaid,
                        isPaidThisCycle: !currentlyPaid,
                    }
                    : debt;
            })
        );
    }

    function handleMarkDebtSnowballPaid(id: string) {
        setDebts((current) =>
            current.map((debt) =>
                debt.id === id
                    ? {
                        ...debt,
                        snowballPaidThisCycle: !debt.snowballPaidThisCycle,
                    }
                    : debt
            )
        );
    }

    function handleMarkRecommendedAction(
        targetId: string,
        label: string,
        category: "emergency" | "snowball",
        recommendedAmount: number,
        actualAmount: number
    ) {
        const existingAction = completedRecommendedActions.find(
            (action) =>
                action.targetId === targetId &&
                action.label === label &&
                action.category === category
        );

        if (existingAction) {

            if (category === "emergency") {
                setGoals((current) =>
                    current.map((goal) =>
                        goal.id === targetId
                            ? {
                                ...goal,
                                currentAmount: Math.max(
                                    0,
                                    goal.currentAmount - existingAction.actualAmount
                                ),
                            }
                            : goal
                    )
                );
            }

            if (category === "snowball") {
                setDebts((current) =>
                    current.map((debt) =>
                        debt.id === targetId
                            ? { ...debt, balance: debt.balance + existingAction.actualAmount, snowballPaidThisCycle: false }
                            : debt
                    )
                );
            }

             setCompletedRecommendedActions((current) =>
                current.filter(
                    (action) =>
                        !(
                            action.targetId === targetId &&
                            action.label === label &&
                            action.category === category
                        )
                )
            );

            return;
        }

        setCompletedRecommendedActions((current) => [
            ...current,
            {
                targetId,
                label,
                category,
                recommendedAmount,
                actualAmount,
            },
        ]);

        if (category === "emergency") {
            setGoals((current) =>
                current.map((goal) =>
                    goal.id === targetId
                        ? {
                            ...goal,
                            currentAmount: Math.min(
                                goal.targetAmount,
                                goal.currentAmount + actualAmount
                            ),
                        }
                        : goal
                )
            );
        }

        if (category === "snowball") {
            setDebts((current) =>
                current.map((debt) =>
                    debt.id === targetId
                        ? { ...debt, balance: Math.max(0, debt.balance - actualAmount), snowballPaidThisCycle: true }
                        : debt
                )
            );
        }
    }

    function handleRolloverPayCycle() {
        setRequiredExpenses((current) => rolloverRequiredExpenses(current));
        setDebts((current) => rolloverDebts(current));
        setCompletedRecommendedActions([]);
    }

    return (
        <main className="app">
            <section className="hero">
                <h1>Debt Planner</h1>
                <p>Enter a paycheck and see exactly what to do next.</p>

                <nav className="tab-bar">
                    <button
                        className={activeTab === "plan" ? "tab active" : "tab"}
                        onClick={() => setActiveTab("plan")}
                    >
                        Plan
                    </button>

                    <button
                        className={activeTab === "snowball" ? "tab active" : "tab"}
                        onClick={() => setActiveTab("snowball")}
                    >
                        Snowball
                    </button>

                    <button
                        className={activeTab === "expenses" ? "tab active" : "tab"}
                        onClick={() => setActiveTab("expenses")}
                    >
                        Expenses
                    </button>

                    <button
                        className={activeTab === "debts" ? "tab active" : "tab"}
                        onClick={() => setActiveTab("debts")}
                    >
                        Debts
                    </button>

                    <button
                        className={activeTab === "goals" ? "tab active" : "tab"}
                        onClick={() => setActiveTab("goals")}
                    >
                        Goals
                    </button>
                </nav>
            </section>

            {activeTab === "plan" && (
                <>
                    <PaycheckSection
                        amount={amount}
                        payCycle={payCycle}
                        semiMonthlyFirstDay={semiMonthlyFirstDay}
                        semiMonthlySecondDay={semiMonthlySecondDay}
                        monthlyPayDay={monthlyPayDay}
                        nextPaycheckDate={nextPaycheckDate}
                        onAmountChange={setAmount}
                        onPayCycleChange={setPayCycle}
                        onSemiMonthlyFirstDayChange={setSemiMonthlyFirstDay}
                        onSemiMonthlySecondDayChange={setSemiMonthlySecondDay}
                        onMonthlyPayDayChange={setMonthlyPayDay}
                        onCalculate={handleCalculate}
                        onRolloverPayCycle={handleRolloverPayCycle}
                    />

                    <ResultsSection
                        result={result}
                        requiredExpenses={requiredExpenses}
                        debts={debts}
                        goals={goals}
                        completedRecommendedActions={completedRecommendedActions}
                        onMarkExpensePaid={handleMarkExpensePaid}
                        onMarkDebtMinimumPaid={handleMarkDebtMinimumPaid}
                        onMarkDebtSnowballPaid={handleMarkDebtSnowballPaid}
                        onMarkRecommendedAction={handleMarkRecommendedAction}
                    />
                </>
            )}

            {activeTab === "snowball" && (
                <SnowballSection debts={debts} result={result} completedRecommendedActions={completedRecommendedActions} />
            )}

            {activeTab === "expenses" && (
                <RequiredExpensesSection
                    expenses={requiredExpenses}
                    expenseName={expenseName}
                    expenseAmount={expenseAmount}
                    expenseDueDate={expenseDueDate}
                    expenseRecurrence={expenseRecurrence}
                    expenseType={expenseType}
                    formatRecurrence={formatRecurrence}
                    onExpenseNameChange={setExpenseName}
                    onExpenseAmountChange={setExpenseAmount}
                    onExpenseDueDateChange={setExpenseDueDate}
                    onExpenseRecurrenceChange={setExpenseRecurrence}
                    onExpenseTypeChange={setExpenseType}
                    onAddExpense={handleAddExpense}
                    onRemoveExpense={handleRemoveExpense}
                    onUpdateExpense={handleUpdateExpense}
                />
            )}

            {activeTab === "debts" && (
                <DebtsSection
                    debtsDueBeforeNextPaycheck={debtsDueBeforeNextPaycheck}
                    debtsDueAfterNextPaycheck={debtsDueAfterNextPaycheck}
                    debtName={debtName}
                    debtBalance={debtBalance}
                    debtMinimumPayment={debtMinimumPayment}
                    debtApr={debtApr}
                    debtDueDate={debtDueDate}
                    debtType={debtType}
                    debtRecurrence={debtRecurrence}
                    formatRecurrence={formatRecurrence}
                    onDebtNameChange={setDebtName}
                    onDebtBalanceChange={setDebtBalance}
                    onDebtMinimumPaymentChange={setDebtMinimumPayment}
                    onDebtAprChange={setDebtApr}
                    onDebtDueDateChange={setDebtDueDate}
                    onDebtTypeChange={setDebtType}
                    onDebtRecurrenceChange={setDebtRecurrence}
                    onAddDebt={handleAddDebt}
                    onRemoveDebt={handleRemoveDebt}
                    onUpdateDebt={handleUpdateDebt}
                    debtErrors={debtErrors}
                />
            )}

            {activeTab === "goals" && (
                <GoalsSection
                    goals={goals}
                    goalName={goalName}
                    goalTargetAmount={goalTargetAmount}
                    goalCurrentAmount={goalCurrentAmount}
                    goalType={goalType}
                    onGoalNameChange={setGoalName}
                    onGoalTargetAmountChange={setGoalTargetAmount}
                    onGoalCurrentAmountChange={setGoalCurrentAmount}
                    onGoalTypeChange={setGoalType}
                    onAddGoal={handleAddGoal}
                    onRemoveGoal={handleRemoveGoal}
                    onUpdateGoal={handleUpdateGoal}
                />
            )}
        </main>
    );
}
