import type { Debt, RequiredExpense } from "../storage/debtPlannerStorage";

function toDate(date: string) {
    return new Date(`${date}T00:00:00`);
} 

function toDateString(date: Date) {
    return date.toISOString().slice(0, 10);
}

function addDays(date: string, days: number) {
    const next = toDate(date);
    next.setDate(next.getDate() + days);
    return toDateString(next);
}

function addMonths(date: string, months: number) {
    const current = toDate(date);
    const next = new Date(current);

    next.setMonth(next.getMonth() + months);

    return toDateString(next);
}

function advanceDueDate(date: string, recurrence: RequiredExpense["recurrence"]) {
    switch (recurrence) {
        case "weekly":
            return addDays(date, 7);
        case "biweekly":
            return addDays(date, 14);
        case "monthly":
            return addMonths(date, 1);
        case "per-paycheck":
            return date;
        default:
            return date;
    }
}

export function rolloverRequiredExpenses(expenses: RequiredExpense[]) {
    return expenses.filter((expense) => !(expense.recurrence === "one-time" && expense.isPaidThisCycle)).map((expense) => {
        if (!expense.isPaidThisCycle) {
            return expense;
        }

         return { ...expense, dueDate: advanceDueDate(expense.dueDate, expense.recurrence), isPaidThisCycle: false,};
    });
}

export function rolloverDebts(debts: Debt[]) {
    return debts.filter((debt) => !(debt.recurrence === "one-time" && debt.isPaidThisCycle)).map((debt) => {
        if (!debt.isPaidThisCycle) {
            return debt;
        }

        return { ...debt, dueDate: advanceDueDate(debt.dueDate, debt.recurrence), isPaidThisCycle: false, minimumPaidThisCycle: false, snowballPaidThisCycle: false};
    });
}