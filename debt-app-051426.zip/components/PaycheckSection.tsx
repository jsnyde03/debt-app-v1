import type { PayCycle } from "@/lib/payCycle/getNextPaycheckDate";

type PaycheckSectionProps = {
    amount: string;
    payCycle: PayCycle;
    semiMonthlyFirstDay: string;
    semiMonthlySecondDay: string;
    monthlyPayDay: string;
    nextPaycheckDate: string;

    onAmountChange: (value: string) => void;
    onPayCycleChange: (value: PayCycle) => void;
    onSemiMonthlyFirstDayChange: (value: string) => void;
    onSemiMonthlySecondDayChange: (value: string) => void;
    onMonthlyPayDayChange: (value: string) => void;
    onCalculate: () => void;
    onRolloverPayCycle: () => void;
}

export function PaycheckSection({ amount, payCycle, semiMonthlyFirstDay, semiMonthlySecondDay, monthlyPayDay, nextPaycheckDate, onAmountChange, onPayCycleChange, onSemiMonthlyFirstDayChange, onSemiMonthlySecondDayChange, onMonthlyPayDayChange, onCalculate, onRolloverPayCycle }: PaycheckSectionProps) {
    return (
        <section className="card">
            <h2>Paycheck</h2>

            <div className="form-grid">
                <div className="field">
                    <label>Paycheck Amount</label>
                    <input type="number" placeholder="Example: 1000" value={amount} onChange={(e) => onAmountChange(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") onCalculate() }} />
                </div>

                <div className="field">
                    <label>Pay Cycle</label>
                    <select value={payCycle} onChange={(e) => onPayCycleChange(e.target.value as PayCycle)}>
                        <option value="weekly">Weekly</option>
                        <option value="biweekly">Bi-Weekly</option>
                        <option value="semimonthly">Semi-Monthly</option>
                        <option value="monthly">Monthly</option>
                    </select>
                </div>

                {payCycle === "semimonthly" && (
                    <>
                        <div className="field">
                            <label>First pay day of month</label>
                            <input
                                type="number"
                                min="1"
                                max="31"
                                value={semiMonthlyFirstDay}
                                onChange={(e) => onSemiMonthlyFirstDayChange(e.target.value)}
                            />
                        </div>

                        <div className="field">
                            <label>Second pay day of month</label>
                            <input
                                type="number"
                                min="1"
                                max="31"
                                value={semiMonthlySecondDay}
                                onChange={(e) => onSemiMonthlySecondDayChange(e.target.value)}
                            />
                        </div>
                    </>
                )}

                {payCycle === "monthly" && (
                    <div className="field">
                        <label>Pay day of month</label>
                        <input
                            type="number"
                            min="1"
                            max="31"
                            value={monthlyPayDay}
                            onChange={(e) => onMonthlyPayDayChange(e.target.value)}
                        />
                    </div>
                )}

                <p className="empty-state">
                    {nextPaycheckDate
                        ? `Plan covers items due before ${nextPaycheckDate}.`
                        : "Enter valid payday settings to calculate your pay period."}
                </p>

                <button onClick={onCalculate}>Calculate plan</button>

                <button className="secondary-button" onClick={onRolloverPayCycle}>
                    Start Next Pay Cycle
                </button>
            </div>
        </section>
    )
}