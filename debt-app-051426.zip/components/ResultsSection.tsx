import { useState } from "react";

import type { allocatePaycheck } from "@/lib/engine/allocatePaycheck";
import type {
    Debt,
    Goal,
    RequiredExpense,
} from "@/lib/storage/debtPlannerStorage";
import { formatCurrency } from "@/lib/utils/formatCurrency";

type AllocationResult = ReturnType<typeof allocatePaycheck>;

type CompletedRecommendedAction = {
    targetId: string;
    label: string;
    category: "emergency" | "snowball";
    recommendedAmount: number;
    actualAmount: number;
};

type VisibleRecommendedAction =
    AllocationResult["allocations"][number] & {
        completed?: boolean;
        actualAmount?: number;
    };

type ResultsSectionProps = {
    result: AllocationResult | null;
    requiredExpenses: RequiredExpense[];
    debts: Debt[];
    goals: Goal[];

    completedRecommendedActions: CompletedRecommendedAction[];

    onMarkExpensePaid: (id: string) => void;
    onMarkDebtMinimumPaid: (id: string) => void;
    onMarkDebtSnowballPaid: (id: string) => void;

    onMarkRecommendedAction: (
        targetId: string,
        label: string,
        category: "emergency" | "snowball",
        recommendedAmount: number,
        actualAmount: number
    ) => void;
};

export function ResultsSection({
    result,
    requiredExpenses,
    debts,
    goals,
    completedRecommendedActions,
    onMarkExpensePaid,
    onMarkDebtMinimumPaid,
    onMarkRecommendedAction,
}: ResultsSectionProps) {
    const [editedAmounts, setEditedAmounts] = useState<Record<string, string>>(
        {}
    );

    const [editingRecommendedKey, setEditingRecommendedKey] = useState<
        string | null
    >(null);

    const [recommendedAmountErrors, setRecommendedAmountErrors] = useState<
        Record<string, string>
    >({});

    if (!result) return null;

    function getActionKey(item: AllocationResult["allocations"][number]) {
        return `${item.category}-${item.targetId}-${item.label}`;
    }

    function getActualAmount(item: AllocationResult["allocations"][number]) {
        const key = getActionKey(item);
        const edited = editedAmounts[key];

        if (!edited || Number.isNaN(Number(edited))) {
            return item.amount;
        }

        const parsed = Number(edited);

        if (!Number.isFinite(parsed)) {
            return item.amount;
        }

        return Math.max(0, parsed);
    }

    function isActionCompleted(item: AllocationResult["allocations"][number]) {
        if (!item.targetId) return false;

        if (item.category === "expense") {
            return requiredExpenses.some(
                (expense) =>
                    expense.id === item.targetId && expense.isPaidThisCycle
            );
        }

        if (item.category === "minimum_debt") {
            return debts.some(
                (debt) =>
                    debt.id === item.targetId &&
                    (debt.minimumPaidThisCycle ?? debt.isPaidThisCycle ?? false)
            );
        }

        if (item.category === "snowball") {
            return completedRecommendedActions.some(
                (action) =>
                    action.targetId === item.targetId &&
                    action.category === "snowball"
            );
        }

        if (item.category === "emergency") {
            return completedRecommendedActions.some(
                (action) =>
                    action.targetId === item.targetId &&
                    action.category === "emergency" &&
                    action.label === item.label
            );
        }

        return false;
    }

    const requiredActions = result.allocations.filter(
        (item) => item.category === "expense" || item.category === "minimum_debt"
    );

    const recommendedActions = result.allocations.filter(
        (item) => item.category === "emergency" || item.category === "snowball"
    );

    const completedRecommendedItems: VisibleRecommendedAction[] =
        completedRecommendedActions.map((action) => ({
            label: action.label,
            amount: action.recommendedAmount,
            category: action.category,
            targetId: action.targetId,
            completed: true,
            actualAmount: action.actualAmount,
        }));

    const visibleRecommendedActions: VisibleRecommendedAction[] = [
        ...recommendedActions.map((item) => {
            const completedAction = completedRecommendedActions.find(
                (action) =>
                    action.targetId === item.targetId &&
                    action.label === item.label &&
                    action.category === item.category
            );

            if (!completedAction) return item;

            return {
                ...item,
                completed: true,
                actualAmount: completedAction.actualAmount,
            };
        }),

        ...completedRecommendedItems.filter(
            (completedAction) =>
                !recommendedActions.some(
                    (item) =>
                        item.targetId === completedAction.targetId &&
                        item.label === completedAction.label &&
                        item.category === completedAction.category
                )
        ),
    ];

    const requiredTotal = requiredActions.reduce(
        (sum, item) => sum + item.amount,
        0
    );

    const completedRecommendedTotal = completedRecommendedActions.reduce(
        (sum, item) => sum + item.actualAmount,
        0
    );

    const remainingRecommendedTotal = visibleRecommendedActions
        .filter((item) => !isActionCompleted(item))
        .reduce((sum, item) => sum + item.amount, 0);

    const flexibleCashAvailable =
        result.paycheckAmount - requiredTotal - completedRecommendedTotal;

    return (
        <div className="results-grid">
            <div className="card">
                <h2>Required Actions</h2>

                {requiredActions.length === 0 ? (
                    <p className="empty-state">No required actions available.</p>
                ) : (
                    requiredActions.map((item, index) => {
                        const completed = isActionCompleted(item);

                        return (
                            <div
                                key={index}
                                className={completed ? "result-row completed-row" : "result-row"}
                            >
                                <div>
                                    <div className="saved-title">{item.label}</div>

                                    <div className="saved-meta">
                                        {item.category === "expense"
                                            ? "Required Expense"
                                            : "Debt Minimum Payment"}
                                    </div>
                                </div>

                                <div className="result-actions">
                                    <strong>{formatCurrency(item.amount)}</strong>

                                    {item.category === "expense" && item.targetId && (
                                        <button
                                            className={
                                                completed
                                                    ? "secondary-button completed-action"
                                                    : "secondary-button"
                                            }
                                            onClick={() => onMarkExpensePaid(item.targetId!)}
                                        >
                                            {completed ? "Undo" : "Mark Paid"}
                                        </button>
                                    )}

                                    {item.category === "minimum_debt" && item.targetId && (
                                        <button
                                            className={
                                                completed
                                                    ? "secondary-button completed-action"
                                                    : "secondary-button"
                                            }
                                            onClick={() => onMarkDebtMinimumPaid(item.targetId!)}
                                        >
                                            {completed ? "Undo" : "Mark Paid"}
                                        </button>
                                    )}
                                </div>
                            </div>
                        );
                    })
                )}
            </div>

            <div className="card">
                <h2>Recommended Actions</h2>

                {visibleRecommendedActions.length === 0 ? (
                    <p className="empty-state">No recommended actions available.</p>
                ) : (
                    visibleRecommendedActions.map((item, index) => {
                        const completed =
                            "completed" in item ? item.completed : isActionCompleted(item);

                        const key = getActionKey(item);
                        const displayAmount =
                            completed && item.actualAmount !== undefined
                                ? item.actualAmount
                                : getActualAmount(item);

                        return (
                            <div
                                key={index}
                                className={completed ? "result-row completed-row" : "result-row"}
                            >
                                <div>
                                    <div className="saved-title">{item.label}</div>

                                    <div className="saved-meta">
                                        {item.category === "emergency"
                                            ? "Goal Contribution"
                                            : "Snowball Payment"}
                                    </div>

                                    {editingRecommendedKey === key ? (
                                        <input
                                            type="number"
                                            value={editedAmounts[key] ?? item.actualAmount ?? item.amount}
                                            onChange={(e) =>
                                                setEditedAmounts((current) => ({
                                                    ...current,
                                                    [key]: e.target.value,
                                                }))
                                            }
                                            className="amount-edit-input"
                                        />
                                    ) : (
                                        <button
                                            className="secondary-button"
                                            onClick={() => setEditingRecommendedKey(key)}
                                        >
                                            Edit Amount
                                        </button>
                                    )}

                                    {recommendedAmountErrors[key] && (
                                        <div className="validation-error">
                                            {recommendedAmountErrors[key]}
                                        </div>
                                    )}
                                </div>

                                <div className="result-actions">
                                    <strong>{formatCurrency(displayAmount)}</strong>

                                    {(item.category === "emergency" ||
                                        item.category === "snowball") &&
                                        item.targetId && (
                                            <button
                                                className={
                                                    completed
                                                        ? "secondary-button completed-action"
                                                        : "secondary-button"
                                                }
                                                onClick={() => {
                                                    const actualAmount = getActualAmount(item);

                                                    if (actualAmount < 0) {
                                                        setRecommendedAmountErrors((current) => ({
                                                            ...current,
                                                            [key]: "Amount cannot be negative.",
                                                        }));

                                                        return;
                                                    }

                                                    if (actualAmount > flexibleCashAvailable && !completed) {
                                                        setRecommendedAmountErrors((current) => ({
                                                            ...current,
                                                            [key]: "Amount exceeds flexible cash.",
                                                        }));

                                                        return;
                                                    }

                                                    if (item.category === "snowball") {
                                                        const debt = debts.find(
                                                            (debt) => debt.id === item.targetId
                                                        );

                                                        if (debt && actualAmount > debt.balance) {
                                                            setRecommendedAmountErrors((current) => ({
                                                                ...current,
                                                                [key]: `Amount exceeds remaining debt balance of ${formatCurrency(
                                                                    debt.balance
                                                                )}.`,
                                                            }));

                                                            return;
                                                        }
                                                    }

                                                    if (item.category === "emergency") {
                                                        const goal = goals.find(
                                                            (goal) => goal.id === item.targetId
                                                        );

                                                        if (goal) {
                                                            const remainingGoalAmount =
                                                                goal.targetAmount - goal.currentAmount;

                                                            if (actualAmount > remainingGoalAmount) {
                                                                setRecommendedAmountErrors((current) => ({
                                                                    ...current,
                                                                    [key]: `Amount exceeds remaining goal amount of ${formatCurrency(
                                                                        remainingGoalAmount
                                                                    )}.`,
                                                                }));

                                                                return;
                                                            }
                                                        }
                                                    }

                                                    if (actualAmount > item.amount && !completed) {
                                                        setRecommendedAmountErrors((current) => ({
                                                            ...current,
                                                            [key]: `You're paying more than recommended. Recommended: ${formatCurrency(
                                                                item.amount
                                                            )}.`,
                                                        }));
                                                    } else {
                                                        setRecommendedAmountErrors((current) => ({
                                                            ...current,
                                                            [key]: "",
                                                        }));
                                                    }

                                                    onMarkRecommendedAction(
                                                        item.targetId!,
                                                        item.label,
                                                        item.category,
                                                        item.amount,
                                                        actualAmount
                                                    );

                                                    setEditingRecommendedKey(null);
                                                }}
                                            >
                                                {completed
                                                    ? "Undo"
                                                    : item.category === "emergency"
                                                        ? "Mark Saved"
                                                        : "Mark Paid"}
                                            </button>
                                        )}
                                </div>
                            </div>
                        );
                    })
                )}
            </div>

            <div className="card">
                <h2>Flexible Cash</h2>

                <div className="result-row">
                    <div>
                        <div className="saved-title">Available Flexible Cash</div>

                        <div className="saved-meta">
                            Completed Recommendations:{" "}
                            {formatCurrency(completedRecommendedTotal)} · Remaining Suggested:{" "}
                            {formatCurrency(remainingRecommendedTotal)}
                        </div>
                    </div>

                    <strong>{formatCurrency(Math.max(0, flexibleCashAvailable))}</strong>
                </div>
            </div>

            <div className="card">
                <h2>Status</h2>
                <p className="status-good">You're on track.</p>
            </div>
        </div>
    );
}
