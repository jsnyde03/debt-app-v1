import { allocatePaycheck } from "../engine/allocatePaycheck";

function assertEqual<T>(actual: T, expected: T, label: string) {
	if (actual !== expected) {
		throw new Error(
			`${label} failed. Expected ${expected}, received ${actual}`
		);
	}
}

function assertExists<T>(value: T | undefined | null, label: string): T {
	if (value === undefined || value === null) {
		throw new Error(`${label} failed. Expected value to exist.`);
	}

	return value;
}

function testAutopayExpenseIsReserved() {
	const result = allocatePaycheck({
		paycheckAmount: 1000,
		currentDate: "2026-06-01",
		nextPaycheckDate: "2026-06-15",
		expenses: [
			{
				id: "rent",
				name: "Rent",
				amount: 500,
				dueDate: "2026-06-03",
				recurrence: "monthly",
				isAutopay: true,
			},
		],
		debts: [],
		goals: [],
		strategy: "snowball",
	});

	const autopayItem = assertExists(
		result.allocations.find((item) => item.category === "autopay_expense"),
		"Autopay expense allocation"
	);

	assertEqual(autopayItem.amount, 500, "Autopay expense amount");
	assertEqual(
		autopayItem.label,
		"Reserve autopay for Rent",
		"Autopay expense label"
	);
}

function testAutopayDebtMinimumIsReserved() {
	const result = allocatePaycheck({
		paycheckAmount: 1000,
		currentDate: "2026-06-01",
		nextPaycheckDate: "2026-06-15",
		expenses: [],
		debts: [
			{
				id: "visa",
				name: "Visa",
				balance: 900,
				minimumPayment: 75,
				apr: 24.99,
				dueDate: "2026-06-04",
				type: "debt",
				recurrence: "monthly",
				isAutopay: true,
			},
		],
		goals: [],
		strategy: "snowball",
	});

	const autopayItem = assertExists(
		result.allocations.find((item) => item.category === "autopay_debt"),
		"Autopay debt allocation"
	);

	assertEqual(autopayItem.amount, 75, "Autopay debt amount");
	assertEqual(
		autopayItem.label,
		"Reserve autopay minimum for Visa",
		"Autopay debt label"
	);
}

function testAutopayStillCountsTowardSnowballBalance() {
	const result = allocatePaycheck({
		paycheckAmount: 1000,
		currentDate: "2026-06-01",
		nextPaycheckDate: "2026-06-15",
		expenses: [],
		debts: [
			{
				id: "small-loan",
				name: "Small Loan",
				balance: 100,
				minimumPayment: 40,
				apr: 10,
				dueDate: "2026-06-04",
				type: "debt",
				recurrence: "monthly",
				isAutopay: true,
			},
		],
		goals: [],
		strategy: "snowball",
		paycheckBuffer: 0,
	});

	const autopayItem = assertExists(
		result.allocations.find((item) => item.category === "autopay_debt"),
		"Autopay minimum allocation before snowball"
	);

	const snowballItem = assertExists(
		result.allocations.find((item) => item.category === "snowball"),
		"Snowball allocation after autopay minimum"
	);

	assertEqual(autopayItem.amount, 40, "Autopay minimum amount");
	assertEqual(snowballItem.amount, 60, "Snowball uses remaining debt balance");
}

function runV11RegressionTests() {
	testAutopayExpenseIsReserved();
	testAutopayDebtMinimumIsReserved();
	testAutopayStillCountsTowardSnowballBalance();

	console.log("✅ V1.1 regression tests passed.");
}

runV11RegressionTests();
