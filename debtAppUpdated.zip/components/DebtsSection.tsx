import type { Debt } from "@/lib/storage/debtPlannerStorage";
import type { Recurrence } from "@/lib/types/recurrence";

import { useState } from "react";

type DebtSectionProps = {
    debtsDueBeforeNextPaycheck: Debt[];
    debtsDueAfterNextPaycheck: Debt[];

    debtName: string;
    debtBalance: string;
    debtMinimumPayment: string;
    debtApr: string;
    debtDueDate: string;
    debtType: "debt" | "bnpl";
    debtRecurrence: Recurrence;
    debtErrors: {name?: string; balance?: string; minimumPayment?: string; dueDate?: string; apr?: string;};

    formatRecurrence: (recurrence: Recurrence) => string;

    onDebtNameChange: (value: string) => void;
    onDebtBalanceChange: (value: string) => void;
    onDebtMinimumPaymentChange: (value: string) => void;
    onDebtAprChange: (value: string) => void;
    onDebtDueDateChange: (value: string) => void;
    onDebtTypeChange: (value: "debt" | "bnpl") => void;
    onDebtRecurrenceChange: (value: Recurrence) => void;

    onAddDebt: () => void;
    onRemoveDebt: (id: string) => void;
    onUpdateDebt: (id: string, updates: Partial<Pick<Debt, "balance" | "minimumPayment" | "dueDate" | "apr">>) => void;
}

export function DebtsSection({ debtsDueBeforeNextPaycheck, debtsDueAfterNextPaycheck, debtName, debtBalance, debtMinimumPayment, debtApr, debtDueDate, debtType, debtRecurrence, formatRecurrence, onDebtNameChange, onDebtBalanceChange, onDebtMinimumPaymentChange, onDebtAprChange, onDebtDueDateChange, onDebtRecurrenceChange, onDebtTypeChange, onAddDebt, onRemoveDebt, onUpdateDebt, debtErrors }: DebtSectionProps) {

    const [editingDebtId, setEditingDebtId] = useState<string | null>(null);
    const [editBalance, setEditBalance] = useState("");
    const [editMinimumPayment, setEditMinimumPayment] = useState("");
    const [editApr, setEditApr] = useState("");
    const [editDueDate, setEditDueDate] = useState("");
    

    function startEditing(debt: Debt) {
        setEditingDebtId(debt.id);
        setEditBalance(String(debt.balance));
        setEditMinimumPayment(String(debt.minimumPayment));
        setEditApr(String(debt.apr));
        setEditDueDate(debt.dueDate);
    }

    function cancelEditing() {
        setEditingDebtId(null);
        setEditBalance("");
        setEditMinimumPayment("");
        setEditApr("");
        setEditDueDate("");
    }

    function saveEditing(id: string) {
        const balance = Number(editBalance);
        const minimumPayment = Number(editMinimumPayment);
        const apr = Number(editApr || 0);

        if (!balance || balance <= 0 || !minimumPayment || minimumPayment < 0 || minimumPayment > balance || apr < 0 || !editDueDate) {
            return;
        }

        onUpdateDebt(id, { balance, minimumPayment, apr, dueDate: editDueDate });

        cancelEditing();
    }

    function renderDebt(debt: Debt) {
        const isEditing = editingDebtId === debt.id;
        return (
            <div key={debt.id} className="saved-item">
                {isEditing ? (
                    <>
                        <div className="field">
                            <label>Current Balance</label>
                            <input type="number" value={editBalance} onChange={(e) => setEditBalance(e.target.value)} />
                        </div>

                        <div className="field">
                            <label>Minimum Payment</label>
                            <input type="number" value={editMinimumPayment} onChange={(e) => setEditMinimumPayment(e.target.value)} />
                        </div>

                        <div className="field">
                            <label>APR (%)</label>
                            <input type="number" value={editApr} onChange={(e) => setEditApr(e.target.value)} />
                        </div>

                        <div className="field">
                            <label>Due Date</label>
                            <input type="date" value={editDueDate} onChange={(e) => setEditDueDate(e.target.value)} />
                        </div>

                        <button className="secondary-button" onClick={() => saveEditing(debt.id)} >
                            Save
                        </button>

                        <button className="secondary-button" onClick={cancelEditing}>
                            Cancel
                        </button>
                    </>
                ) : (
                    <>
                        <div>
                            <div className="saved-title">
                                {debt.name}
                                {debt.isPaidThisCycle ? "✔" : ""}
                            </div>

                            <div className="saved-meta">
                                Balance ${debt.balance} · Min ${debt.minimumPayment} · ARP{" "}
                                {debt.apr} · Due {debt.dueDate} · {" "}
                                {formatRecurrence(debt.recurrence)}
                            </div>
                        </div>

                        <div className="saved-amount">${debt.minimumPayment}</div>

                        <div className="saved-actions">
                            <button className="text-action-button" onClick={() => startEditing(debt)}>
                                Edit
                            </button>

                            <button className="text-action-button danger-action" onClick={() => onRemoveDebt(debt.id)}>
                                Remove
                            </button>

                        </div>

                    </>
                )}
            </div>
        );
    }

    return (
        <section className="card">
            <h2>Debts</h2>

            <div className="form-grid">
                <div className="field">
                    <label>Debt Name</label>
                    <input type="text" placeholder="Credit Card, Afterpay, Loan" value={debtName} onChange={(e) => onDebtNameChange(e.target.value)} />
                    {debtErrors.name && (<p className="validation-error">{debtErrors.name} </p>)}
                </div>

                <div className="field">
                    <label>Current Balance</label>
                    <input type="number" placeholder="Total Balance Owed" value={debtBalance} onChange={(e) => onDebtBalanceChange(e.target.value)} />
                    {debtErrors.balance && (<p className="validation-error">{debtErrors.balance} </p>)}
                </div>

                <div className="field">
                    <label>Minimum Payment</label>
                    <input type="number" placeholder="Minimum Payment" value={debtMinimumPayment} onChange={(e) => onDebtMinimumPaymentChange(e.target.value)} />
                    {debtErrors.minimumPayment && (<p className="validation-error">{debtErrors.minimumPayment} </p>)}
                </div>

                <div className="field">
                    <label>APR (%)</label>
                    <input type="number" placeholder="Example: 24.99" value={debtApr} onChange={(e) => onDebtAprChange(e.target.value)} />
                    {debtErrors.apr && (<p className="validation-error">{debtErrors.apr} </p>)}
                </div>

                <div className="field">
                    <label>Due Date</label>
                    <input type="date" value={debtDueDate} onChange={(e) => onDebtDueDateChange(e.target.value)} />
                    {debtErrors.dueDate && (<p className="validation-error">{debtErrors.dueDate} </p>)}
                </div>

                <div className="field">
                    <label>Type</label>
                    <select value={debtType} onChange={(e) => onDebtTypeChange(e.target.value as "debt" | "bnpl")}>
                        <option value="debt">Debt</option>
                        <option value="bnpl">BNPL</option>
                    </select>
                </div>

                <div className="field">
                    <label>Recurrence</label>
                    <select value={debtRecurrence} onChange={(e) => onDebtRecurrenceChange(e.target.value as Recurrence)}>
                        <option value="monthly">Monthly</option>
                        <option value="weekly">Weekly</option>
                        <option value="biweekly">Every 2 weeks</option>
                        <option value="per-paycheck">Per Paycheck</option>
                        <option value="one-time">One-time</option>
                    </select>
                </div>
                <button className="add-button" onClick={onAddDebt}>
                    Add Debt
                </button>
            </div>

            <div className="debt-group">
                <h3>Due Before Next Paycheck</h3>

                {debtsDueBeforeNextPaycheck.length === 0 ? (
                    <p className="empty-state">No debts due before next paycheck.</p>
                ) : (
                    debtsDueBeforeNextPaycheck.map(renderDebt)
                )}
            </div>

            <div className="debt-group">
                <h3>Due After Next Paycheck</h3>

                {debtsDueAfterNextPaycheck.length === 0 ? (
                    <p className="empty-state">No debts due after next paycheck.</p>
                ) : (
                    debtsDueAfterNextPaycheck.map(renderDebt)
                )}
            </div>
        </section>
    );
}