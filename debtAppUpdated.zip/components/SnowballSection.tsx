import type { Debt } from "@/lib/storage/debtPlannerStorage";
import type { allocatePaycheck } from "@/lib/engine/allocatePaycheck";
import { projectDebtPayoff } from "@/lib/debt/projectDebtPayoff";
import { formatCurrency } from "@/lib/utils/formatCurrency";

type AllocationResult = ReturnType<typeof allocatePaycheck>;

type CompletedRecommendedAction = {
    targetId: string;
    label: string;
    category: "emergency" | "snowball";
    recommendedAmount: number;
    actualAmount: number
}

type SnowballSectionProps = {
    debts: Debt[];
    result: AllocationResult | null;
    completedRecommendedActions: CompletedRecommendedAction[];
}



export function SnowballSection({ debts, result, completedRecommendedActions, }: SnowballSectionProps) {
    const snowballOrder = [...debts].filter((debt) => debt.balance > 0).sort((a, b) => a.balance - b.balance);
    const snowballAllocations = result?.allocations.filter((item) => item.category === "snowball") ?? [];

    const currentTarget = snowballOrder[0];
    
    const recommendedSnowballExtra = result?.allocations.filter((item) => item.category === "snowball").reduce((sum, item) => sum + item.amount, 0) ?? 0;
    const baselineProjection = projectDebtPayoff({
        debts,
        monthlyExtraPayment: 0,
        strategy: "snowball",
        startDate: new Date().toISOString().slice(0, 10);
    });
    const projectedSnowball = projectDebtPayoff({
        debts,
        monthlyExtraPayment: recommendedSnowballExtra,
        strategy: "snowball",
        startDate: new Date().toISOString().slice(0, 10);
    })
    const baselineCanBeEstimated = baselineProjection.estimatedDebtFreeDate !== "Unable to estimate";
    const projectedCanBeEstimated = projectedSnowball.estimatedDebtFreeDate !== "Unable to estimate";
    const estimatedInterestSaved = baselineCanBeEstimated && projectedCanBeEstimated ? Math.max(0, baselineProjection.totalInterestPaid - projectedSnowball.totalInterestPaid) : null;
   
    return (
        <section className="card">
            <h2>Debt Snowball</h2>

            {!currentTarget ? (
                <p className="empty-state">No active debts added yet.</p>
            ) : (
                <>
                    <div className="snowball-target">
                        <p className="empty-state">Current Target</p>
                        <h3>{currentTarget.name}</h3>
                        <p>Balance: <strong>{formatCurrency(currentTarget.balance)}</strong></p>
                    </div>

                    <div className="debt-group">
                        <h3>Projected Payoff</h3>

                        <div className="saved-item">
                            <div>
                                <div className="saved-title">Estimated Debt-Free Date</div>
                                <div className="saved-meta">Based on minimum payment plus this paychecks recommended snowball amount.</div>
                            </div>

                            <div className="saved-meta">
                                Active extra payment: {formatCurrency(recommendedSnowballExtra)}/ month;
                            </div>

                            <div className="saved-amount">
                                {projectedSnowball.estimatedDebtFreeDate}
                            </div>
                        </div>
                        <div className="saved-item">
                            <div>
                                <div className="saved-title">Estimated Interest Paid</div>
                                <div className="saved-meta">Based on current balances, APRs, minimums, and extra snowball amount</div>
                            </div>

                            <div className="saved-amount">
                                {formatCurrency(projectedSnowball.totalInterestPaid)}
                            </div>
                        </div>
                        <div className="saved-item">
                            <div>
                                <div className="saved-title">Estimated Interest Saved</div>
                                <div className="saved-meta">Compared with minimum payments only</div>
                            </div>
                        </div>

                        <div className="saved-amount">
                            {estimatedInterestSaved === null ? "Unable to estimate" : formatCurrency(estimatedInterestSaved)}
                        </div>
                    </div>

                    <div className="debt-group">
                        <h3>Payoff Order</h3>

                        {snowballOrder.map((debt, index) => (
                            <div key={debt.id} className="saved-item">
                                <div>
                                    <div className="saved-title">
                                        #{index + 1} {debt.name}
                                    </div>
                                    <div className="saved-meta">
                                        Balance {formatCurrency(debt.balance)}  · Min {formatCurrency(debt.minimumPayment)} · APR{" "} {debt.apr}%
                                    </div>

                                    <div className="saved-amount">{formatCurrency(debt.balance)}</div>
                                </div>
                            </div>
                        ))}
                    </div>

                    <div className="debt-group">
                        <h3>This Paycheck's Snowball Amount</h3>

                        {snowballAllocations.length === 0 ? (
                            <p className="empty-state">No extra snowball payment available from this paycheck.</p>
                        ) : (
                            snowballAllocations.map((item, index) =>
                                <div key={index} className="result-row">
                                    <span>{item.label}</span>
                                    <strong>{formatCurrency(item.amount)}</strong>
                                </div>
                            )
                        )}
                    </div>
                </>
            )}
        </section>

    );
}