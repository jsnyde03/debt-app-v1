import type { Recurrence } from "../types/recurrence";

export type Expense = {
	id: string;
	name: string;
	amount: number;
	dueDate: string;
	recurrence: Recurrence;
	isPaidThisCycle?: boolean;
};

export type Debt = {
	id: string;
	name: string;
	balance: number;
	minimumPayment: number;
	dueDate: string;
	type: "debt" | "bnpl";
	recurrence: Recurrence;
	isPaidThisCycle?: boolean;
};

export type Goal = {
	id: string;
	name: string;
	targetAmount: number;
	currentAmount: number;
	type: "emergency" | "savings";
};

export type AllocationItem = {
	label: string;
	amount: number;
	category: "expense" | "minimum_debt" | "emergency" | "snowball" | "leftover";
	targetId?: string;
	debtId?: string;
	goalId?: string;
};

export type UnfundedRequiredItem = {
	label: string;
	amount: number;
	category: "expense" | "minimum_debt";
	debtId?: string;
};

type AllocatePaycheckParams = {
	paycheckAmount: number;
	currentDate: string;
	nextPaycheckDate: string;
	expenses: Expense[];
	debts: Debt[];
	goals: Goal[];
	paycheckBuffer?: number;
};

export function allocatePaycheck({
	paycheckAmount,
	currentDate,
	nextPaycheckDate,
	expenses,
	debts,
	goals,
	paycheckBuffer = 50,
}: AllocatePaycheckParams) {
	const roundMoney = (amount: number) => Math.round(amount * 100) / 100;
	let remaining = paycheckAmount;

	const allocations: AllocationItem[] = [];
	const unfundedRequiredItems: UnfundedRequiredItem[] = [];

	const isDueBeforeNextPaycheck = (dueDate: string) => {
		const due = new Date(dueDate);
		return due >= new Date(currentDate) && due < new Date(nextPaycheckDate);
	};

	const upcomingExpenses = expenses
		.filter((expense) => isDueBeforeNextPaycheck(expense.dueDate))
		.sort(
			(a, b) =>
				new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()
		);

	const upcomingMinimums = debts
		.filter((debt) => isDueBeforeNextPaycheck(debt.dueDate))
		.sort(
			(a, b) =>
				new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()
		);



	const totalRequired =
		upcomingExpenses.reduce((sum, expense) => sum + expense.amount, 0) +
		upcomingMinimums.reduce((sum, debt) => sum + debt.minimumPayment, 0);

	const shortfall = Math.max(0, totalRequired - paycheckAmount);

	const paidTowardDebt = (debtId: string) =>
		allocations
			.filter(
				(item) =>
					item.debtId === debtId &&
					(item.category === "minimum_debt" || item.category === "snowball")
			)
			.reduce((sum, item) => sum + item.amount, 0);

	for (const expense of upcomingExpenses) {
		const coveredAmount = Math.min(expense.amount, remaining);
		const unfundedAmount = expense.amount - coveredAmount;

		if (coveredAmount > 0) {
			allocations.push({
				label:
					coveredAmount === expense.amount
						? `Pay ${expense.name}`
						: `Pay ${expense.name} (partial)`,
				amount: coveredAmount,
				category: "expense",
				targetId: expense.id,
			});

			remaining -= coveredAmount;
		}

		if (unfundedAmount > 0) {
			unfundedRequiredItems.push({
				label:
					coveredAmount > 0 ? `Finish ${expense.name}` : `Pay ${expense.name}`,
				amount: unfundedAmount,
				category: "expense",
			});
		}
	}

	for (const debt of upcomingMinimums) {
		const remainingDebtBalance = Math.max(
			0,
			debt.balance - paidTowardDebt(debt.id)
		);

		const requiredMinimum = Math.min(debt.minimumPayment, remainingDebtBalance);
		const coveredAmount = Math.min(requiredMinimum, remaining);
		const unfundedAmount = requiredMinimum - coveredAmount;

		if (coveredAmount > 0) {
			allocations.push({
				label:
					coveredAmount === requiredMinimum
						? `Pay minimum on ${debt.name}`
						: `Pay minimum on ${debt.name} (partial)`,
				amount: coveredAmount,
				category: "minimum_debt",
				targetId: debt.id,
				debtId: debt.id,
			});

			remaining -= coveredAmount;
		}

		if (unfundedAmount > 0) {
			unfundedRequiredItems.push({
				label:
					coveredAmount > 0
						? `Pay remaining minimum on ${debt.name}`
						: `Pay minimum on ${debt.name}`,
				amount: unfundedAmount,
				category: "minimum_debt",
				debtId: debt.id,
			});
		}
	}

	if (shortfall === 0 && remaining > 0 && paycheckBuffer > 0) {
		const amount = Math.min(paycheckBuffer, remaining);

		allocations.push({
			label: "Keep cash buffer",
			amount: roundMoney(amount),
			category: "leftover",
		});

		remaining = roundMoney(remaining - amount);
	}

	const emergencyGoal = goals.find((goal) => goal.type === "emergency");

	if (
		emergencyGoal &&
		emergencyGoal.currentAmount < emergencyGoal.targetAmount &&
		remaining > 0
	) {
		const emergencyNeeded =
			emergencyGoal.targetAmount - emergencyGoal.currentAmount;

		const amount = Math.min(emergencyNeeded, remaining);

		allocations.push({
			label: `Add to ${emergencyGoal.name}`,
			amount,
			category: "emergency",
			targetId: emergencyGoal.id,
			goalId: emergencyGoal.id,
		});

		remaining -= amount;
	}

	const savingsGoals = goals.filter((goal) => goal.type === "savings" && goal.currentAmount < goal.targetAmount);

	for (const goal of savingsGoals) {
		if (remaining < 0) break;

		const needed = goal.targetAmount - goal.currentAmount;
		const amount = roundMoney(Math.min(remaining, needed));

		allocations.push({
			label: `Add to ${goal.name}`,
			amount,
			category: "emergency",
			targetId: goal.id,
			goalId: goal.id,
		});

		remaining = roundMoney(remaining - amount);
	}

	const sortedSnowballDebts = debts
		.filter((debt) => debt.balance - paidTowardDebt(debt.id) > 0)
		.sort((a, b) => a.balance - b.balance);

	for (const debt of sortedSnowballDebts) {
		if (remaining <= 0) break;

		const remainingDebtBalance = debt.balance - paidTowardDebt(debt.id);
		const amount = roundMoney(Math.min(remaining, remainingDebtBalance));

		if (amount <= 0) continue;

		allocations.push({
			label: `Extra payment to ${debt.name}`,
			amount,
			category: "snowball",
			targetId: debt.id,
			debtId: debt.id,
		});

		remaining = roundMoney(remaining - amount);
	}

	if (remaining > 0) {
		allocations.push({
			label: "Leftover cash",
			amount: roundMoney(remaining),
			category: "leftover",
		});
	}

	return {
		paycheckAmount,
		allocations,
		unfundedRequiredItems,
		remaining,
		totalRequired,
		shortfall,
	};
}
